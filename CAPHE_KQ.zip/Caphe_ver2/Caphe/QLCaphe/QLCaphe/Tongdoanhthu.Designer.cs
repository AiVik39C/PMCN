﻿namespace QLCaphe
{
    partial class Tongdoanhthu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tongdoanhthu));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_in = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txttongtien = new System.Windows.Forms.RichTextBox();
            this.groupBoxTONGDOANHTHU = new System.Windows.Forms.GroupBox();
            this.dg_dshd = new System.Windows.Forms.DataGridView();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxTONGDOANHTHU.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dshd)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_in);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox3.ForeColor = System.Drawing.Color.Red;
            this.groupBox3.Location = new System.Drawing.Point(441, 415);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(128, 87);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "In doanh thu";
            // 
            // btn_in
            // 
            this.btn_in.BackColor = System.Drawing.Color.Transparent;
            this.btn_in.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_in.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_in.Image = global::QLCaphe.Properties.Resources.BTTOI__26_;
            this.btn_in.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_in.Location = new System.Drawing.Point(17, 25);
            this.btn_in.Name = "btn_in";
            this.btn_in.Size = new System.Drawing.Size(67, 52);
            this.btn_in.TabIndex = 0;
            this.btn_in.Text = "In";
            this.btn_in.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_in.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txttongtien);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(8, 415);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(427, 87);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tổng doanh thu";
            // 
            // txttongtien
            // 
            this.txttongtien.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txttongtien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txttongtien.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txttongtien.Location = new System.Drawing.Point(3, 22);
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txttongtien.Size = new System.Drawing.Size(421, 62);
            this.txttongtien.TabIndex = 2;
            this.txttongtien.Text = "";
            // 
            // groupBoxTONGDOANHTHU
            // 
            this.groupBoxTONGDOANHTHU.Controls.Add(this.dg_dshd);
            this.groupBoxTONGDOANHTHU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxTONGDOANHTHU.ForeColor = System.Drawing.Color.Red;
            this.groupBoxTONGDOANHTHU.Location = new System.Drawing.Point(5, 3);
            this.groupBoxTONGDOANHTHU.Name = "groupBoxTONGDOANHTHU";
            this.groupBoxTONGDOANHTHU.Size = new System.Drawing.Size(564, 406);
            this.groupBoxTONGDOANHTHU.TabIndex = 3;
            this.groupBoxTONGDOANHTHU.TabStop = false;
            this.groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn theo:";
            // 
            // dg_dshd
            // 
            this.dg_dshd.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dg_dshd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dg_dshd.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dg_dshd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_dshd.DefaultCellStyle = dataGridViewCellStyle1;
            this.dg_dshd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg_dshd.EnableHeadersVisualStyles = false;
            this.dg_dshd.Location = new System.Drawing.Point(3, 22);
            this.dg_dshd.Name = "dg_dshd";
            this.dg_dshd.Size = new System.Drawing.Size(558, 381);
            this.dg_dshd.TabIndex = 0;
            // 
            // Tongdoanhthu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 504);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBoxTONGDOANHTHU);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Tongdoanhthu";
            this.Text = "Tổng doanh thu";
            this.Load += new System.EventHandler(this.Tongdoanhthu_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBoxTONGDOANHTHU.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_dshd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_in;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox txttongtien;
        private System.Windows.Forms.GroupBox groupBoxTONGDOANHTHU;
        private System.Windows.Forms.DataGridView dg_dshd;
    }
}