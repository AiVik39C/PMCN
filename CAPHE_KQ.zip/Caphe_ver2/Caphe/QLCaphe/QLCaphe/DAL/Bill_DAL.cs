﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class Bill_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable load_bill()
        {
            string sql = "SELECT * FROM Bill";
            return ketnoi.Load_Data(sql);
        }
        public int insert_bill(Bill_PUBLIC bill_public)
        {
            int parameter = 5;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@dateCheckin";
            name[1] = "@dateCheckout";
            name[2] = "@idban";
            name[3] = "@idnv";
            name[4] = "@trangthai";

            values[0] = bill_public.dateCheckin;
            values[1] = bill_public.dateCheckout;
            values[2] = bill_public.idban;
            values[3] = bill_public.idnv;
            values[4] = bill_public.trangthai;
            DateTime datecheckin = bill_public.dateCheckin;
            DateTime datecheckout = bill_public.dateCheckout;
            int idban = bill_public.idban;
            int idnv = bill_public.idnv;
            string trangthai = bill_public.trangthai;
            string sql = "INSERT INTO Bill(dateCheckin,dateCheckout,idban,idnv,trangthai) VALUES('"+datecheckin+"','"+datecheckout+"','"+idban+"','1',N'"+trangthai+"')";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_bill(Bill_PUBLIC bill_public)
        {
            int parameter = 6;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            name[1] = "@dateCheckin";
            name[2] = "@dateCheckout";
            name[3] = "@idban";
            name[4] = "@idnv";
            name[5] = "@trangthai";
            values[0] = bill_public.id;
            values[1] = bill_public.dateCheckin;
            values[2] = bill_public.dateCheckout;
            values[3] = bill_public.idban;
            values[4] = bill_public.idnv;
            values[5] = bill_public.trangthai;
            int id = bill_public.id;
            DateTime datecheckin = bill_public.dateCheckin;
            DateTime datecheckout = bill_public.dateCheckout;
            int idban = bill_public.idban;
            int idnv = bill_public.idnv;
            string trangthai = bill_public.trangthai;
            string sql = "UPDATE Bill SET dateCheckin='"+datecheckin+"',dateCheckout='"+datecheckout+"',idban='"+idban+"',idnv='"+idnv+"',trangthai='"+trangthai +"WHERE id="+id+"";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_bill(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            values[0] = bill_public.id;
            int id = bill_public.id;
            string sql = "DELETE FROM Bill WHERE id="+id+"";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int count_bill_ban(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idban";
            values[0] = bill_public.idban;
            string sql = "SELECT COUNT(*) from Bill where Bill.idban=@idban";
            return ketnoi.ReturnValueIntWithParameter(sql, name, values, parameter);
        }
        public int delete_bill_with_idban(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idban";
            values[0] = bill_public.idban;
            string sql = "DELETE FROM Bill WHERE idban=@idban";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int load_idban_with_id(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            values[0] = bill_public.id;
            string sql = "select Bill.idban from Bill where Bill.id=@id";
            return ketnoi.ReturnValueIntWithParameter(sql, name, values, parameter);
        }
        public int load_id_with_idban(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idban";
            values[0] = bill_public.idban;
            int idban = bill_public.idban;
            string sql = "select Bill.id from Bill where Bill.idban="+idban+"";
            return ketnoi.ReturnValueIntWithParameter(sql, name, values, parameter);
        }
        public int update_bill_doiban(Bill_PUBLIC bill_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            name[1] = "@idban";
            values[0] = bill_public.id;
            values[1] = bill_public.idban;
            int id = bill_public.id;
            int idban = bill_public.idban;
            string sql = "UPDATE Bill SET idban='"+idban+"' WHERE id= '"+id+"'";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int load_idnv(Bill_PUBLIC bill_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            values[0] = bill_public.id;
            int id = bill_public.id;
            string sql = "Select idnv FROM Bill WHERE id="+id+"";
            return ketnoi.ReturnValueInt(sql);
        }
    }
}
