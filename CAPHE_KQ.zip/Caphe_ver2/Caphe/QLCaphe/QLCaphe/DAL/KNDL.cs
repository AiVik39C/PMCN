﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    class KNDL
    {
        SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-P5PV1GG\SQLEXPRESS;Initial Catalog=CAPHE;Integrated Security=True");
        public KNDL()
        {
            if (connect.State == ConnectionState.Closed)
            {
                connect.Open();
            }
        }
        public DataTable Load_Data(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public int ReturnValueIntWithParameter(string sql, string[] name, object[] values, int parameter)
        {
            SqlCommand cmd = new SqlCommand(sql, connect);
            cmd.CommandType = CommandType.Text;
            for (int i = 0; i < parameter; i++)
            {
                cmd.Parameters.AddWithValue(name[i], values[i]);
            }
            return int.Parse(cmd.ExecuteScalar().ToString());
        }
        public DataTable LoadDataWithParameter(string sql, string[] name, object[] values, int parameter)
        {
            SqlCommand cmd = new SqlCommand(sql, connect);
            cmd.CommandType = CommandType.Text;
            for (int i = 0; i < parameter; i++)
            {
                cmd.Parameters.AddWithValue(name[i], values[i]);
            }
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }
        public int Excute_Data(string sql, string[] name, object[] values, int parameter)
        {
            SqlCommand cmd = new SqlCommand(sql, connect);
            cmd.CommandType = CommandType.Text;
            for (int i = 0; i < parameter; i++)
            {
                cmd.Parameters.AddWithValue(name[i], values[i]);
            }
            return cmd.ExecuteNonQuery();
        }
        public int ReturnValueInt(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect);
            cmd.CommandType = CommandType.Text;
            return int.Parse(cmd.ExecuteScalar().ToString());
        }

        public DataSet loadComboBox(string sql){
            DataSet dataSet = new DataSet();
            SqlCommand cmd = new SqlCommand(sql, connect);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dataSet);
            return dataSet;
        }
        
    }
}
