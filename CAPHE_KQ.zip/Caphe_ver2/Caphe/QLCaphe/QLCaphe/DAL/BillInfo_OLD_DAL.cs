﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class BillInfo_OLD_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable load_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill_OLD";
            values[0] = billinfo_old.idbill_OLD;
            string sql = "SELECT BillInfo_OLD.idbillinfo_OLD,BillInfo_OLD.idbill_OLD,BillInfo_OLD.idfood,Food.name,BillInfo_OLD.soluong,Food.Gia,(BillInfo_OLD.soluong*Food.Gia) FROM BillInfo_OLD INNER JOIN Food ON BillInfo_OLD.idfood=Food.id WHERE idbill_OLD=@idbill_OLD";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable load_billinfo_old_printer(BillInfo_OLD_PUBLIC billinfo_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill_OLD";
            values[0] = billinfo_old.idbill_OLD;
            string sql = "SELECT Food.name,BillInfo_OLD.soluong,Food.Gia,(BillInfo_OLD.soluong*Food.Gia) FROM BillInfo_OLD INNER JOIN Food ON BillInfo_OLD.idfood=Food.id WHERE idbill_OLD=@idbill_OLD";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public int insert_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            int parameter = 3;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill_OLD";
            name[1] = "@idfood";
            name[2] = "@soluong";
            values[0] = billinfo_old.idbill_OLD;
            values[1] = billinfo_old.idfood;
            values[2] = billinfo_old.soluong;
            int idbill_old = billinfo_old.idbill_OLD;
            int idfood = billinfo_old.idfood;
            int soluong = billinfo_old.soluong;
            string sql = "INSERT INTO BillInfo_OLD(idbill_OLD,idfood,soluong) VALUES ('"+idbill_old+"','"+idfood+"','"+soluong+"')";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill_OLD";
            values[0] = billinfo_old.idbill_OLD;
            int idbill_OLD = billinfo_old.idbill_OLD;
            string sql = "DELETE FROM BillInfo_OLD WHERE idbill_OLD=@idbill_OLD";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
    }
}
