﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    class Khachhang_DAL
    {
        KNDL ketnoi = new KNDL();

       
        public DataTable load_khachhang()
        {
            string sql = "select * from KHACHHANG";
            return ketnoi.Load_Data(sql);
        }
        public DataSet Loadtenkh(Khachhang_PUBLIC food_public)
        {
            
            string sql = "SELECT KHACHHANG.TenKH, KHACHHANG.maKH FROM KHACHHANG";
            return ketnoi.loadComboBox(sql);
        }
        public int insert_khachhang(Khachhang_PUBLIC kh_public)
        {
            int parameter = 5;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
           
            name[0] = "@TenKH";
            name[1] = "@Ngaysinh";
            name[2] = "@Sodienthoai";
            name[3] = "@Gioitinh";
            name[4] = "@tichluy";
            values[0] = kh_public.TenKH;
            values[1] = kh_public.Ngaysinh;
            values[2] = kh_public.Sodienthoai;
            values[3] = kh_public.Gioitinh;
            values[4] = kh_public.tichluy;
            string sql = "INSERT INTO KHACHHANG(TenKH,Ngaysinh,Sodienthoai,Gioitinh,tichluy) VALUES(@TenKH,@Ngaysinh,@Sodienthoai,@Gioitinh,@tichluy)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_khachhang(Khachhang_PUBLIC kh_public)
        {
            int parameter = 6;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@makh";
            name[1] = "@TenKH";
            name[2] = "@Ngaysinh";
            name[3] = "@Sodienthoai";
            name[4] = "@Gioitinh";
            name[5] = "@tichluy";

            values[0] = kh_public.makh;
            values[1] = kh_public.TenKH;
            values[2] = kh_public.Ngaysinh;
            values[3] = kh_public.Sodienthoai;
            values[4] = kh_public.Gioitinh;
            values[5] = kh_public.tichluy;
            string sql = "UPDATE KHACHHANG SET TenKH=@TenKH,Ngaysinh =@Ngaysinh ,Sodienthoai=@Sodienthoai,Gioitinh=@Gioitinh,tichluy=@tichluy  where maKH=@makh";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_khachhang(Khachhang_PUBLIC kh_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@makh";
            values[0] = kh_public.makh;
            string sql = "DELETE FROM KHACHHANG WHERE maKH=@makh";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int congtichluy(Khachhang_PUBLIC kh_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[1] = "@makh";
            values[1] = kh_public.makh;
            name[0] = "@tongtien";
            values[0] = kh_public.tongtien;
            float tongtien = kh_public.tongtien;
            int makh = kh_public.makh;
            string sql = "Update KHACHHANG SET tichluy = tichluy +" + tongtien + " where maKH= '" + makh + "'";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public DataTable Tim_kh(Khachhang_PUBLIC kh_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@TenKH";
            values[0] = kh_public.TIMTEN;
            string tim = kh_public.TIMTEN;
            string sql = "SELECT KHACHHANG.maKH,KHACHHANG.TenKH,KHACHHANG.Ngaysinh,KHACHHANG.Sodienthoai,KHACHHANG.Gioitinh,KHACHHANG.tichluy FROM KHACHHANG where KHACHHANG.TenKH like  '%' +N'"+ tim +"'+'%'";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
    }
}
