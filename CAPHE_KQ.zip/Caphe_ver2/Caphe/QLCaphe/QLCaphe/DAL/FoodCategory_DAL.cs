﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class FoodCategory_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataSet load_dmdouong()
        {
            string sql = "SELECT * FROM FoodCategory";
            return ketnoi.loadComboBox(sql);
        }
        public int insert_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@tendm";
            values[0] = dmdouong_public.tendm;
            string tendm = dmdouong_public.tendm;
            string sql = "INSERT INTO FoodCategory(name) VALUES('"+tendm+"')";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@iddm";
            name[1] = "@tendm";
            values[0] = dmdouong_public.iddm;
            values[1] = dmdouong_public.tendm;
            int iddm = dmdouong_public.iddm;
            string tendm = dmdouong_public.tendm;
            string sql = "UPDATE FoodCategory SET name='"+tendm+"' WHERE id='"+iddm+"'";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@iddm";
            values[0] = dmdouong_public.iddm;
            int iddm = dmdouong_public.iddm;
            string sql = "DELETE FROM FoodCategory WHERE id='"+iddm+"'";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
    }
}
