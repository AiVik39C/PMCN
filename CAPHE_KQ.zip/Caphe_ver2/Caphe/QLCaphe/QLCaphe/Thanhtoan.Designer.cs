﻿namespace QLCaphe
{
    partial class Thanhtoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Thanhtoan));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_thanhtoan = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_tongtien = new System.Windows.Forms.RichTextBox();
            this.groupBoxhd = new System.Windows.Forms.GroupBox();
            this.datagrid_mon = new System.Windows.Forms.DataGridView();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBoxhd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_mon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_thanhtoan);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox3.ForeColor = System.Drawing.Color.Red;
            this.groupBox3.Location = new System.Drawing.Point(546, 283);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(106, 84);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thanh toán";
            // 
            // btn_thanhtoan
            // 
            this.btn_thanhtoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_thanhtoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_thanhtoan.Image = global::QLCaphe.Properties.Resources.BTTOI__11_;
            this.btn_thanhtoan.Location = new System.Drawing.Point(19, 16);
            this.btn_thanhtoan.Name = "btn_thanhtoan";
            this.btn_thanhtoan.Size = new System.Drawing.Size(68, 62);
            this.btn_thanhtoan.TabIndex = 4;
            this.btn_thanhtoan.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_thanhtoan.UseVisualStyleBackColor = true;
            this.btn_thanhtoan.Click += new System.EventHandler(this.btn_thanhtoan_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.txt_tongtien);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(11, 283);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(529, 84);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tổng Tiền (VNĐ)";
            // 
            // txt_tongtien
            // 
            this.txt_tongtien.BackColor = System.Drawing.SystemColors.Control;
            this.txt_tongtien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_tongtien.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_tongtien.Location = new System.Drawing.Point(3, 20);
            this.txt_tongtien.Name = "txt_tongtien";
            this.txt_tongtien.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_tongtien.Size = new System.Drawing.Size(523, 61);
            this.txt_tongtien.TabIndex = 1;
            this.txt_tongtien.Text = "";
            // 
            // groupBoxhd
            // 
            this.groupBoxhd.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxhd.Controls.Add(this.datagrid_mon);
            this.groupBoxhd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBoxhd.ForeColor = System.Drawing.Color.Red;
            this.groupBoxhd.Location = new System.Drawing.Point(8, 7);
            this.groupBoxhd.Name = "groupBoxhd";
            this.groupBoxhd.Size = new System.Drawing.Size(644, 273);
            this.groupBoxhd.TabIndex = 4;
            this.groupBoxhd.TabStop = false;
            this.groupBoxhd.Text = "Hóa đơn";
            // 
            // datagrid_mon
            // 
            this.datagrid_mon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagrid_mon.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.datagrid_mon.BackgroundColor = System.Drawing.SystemColors.Control;
            this.datagrid_mon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrid_mon.DefaultCellStyle = dataGridViewCellStyle1;
            this.datagrid_mon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datagrid_mon.EnableHeadersVisualStyles = false;
            this.datagrid_mon.Location = new System.Drawing.Point(3, 20);
            this.datagrid_mon.Name = "datagrid_mon";
            this.datagrid_mon.Size = new System.Drawing.Size(638, 250);
            this.datagrid_mon.TabIndex = 1;
            // 
            // Thanhtoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 372);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBoxhd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Thanhtoan";
            this.Text = "Thanh toán";
            this.Load += new System.EventHandler(this.Thanhtoan_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBoxhd.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_mon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_thanhtoan;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox txt_tongtien;
        private System.Windows.Forms.GroupBox groupBoxhd;
        private System.Windows.Forms.DataGridView datagrid_mon;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}