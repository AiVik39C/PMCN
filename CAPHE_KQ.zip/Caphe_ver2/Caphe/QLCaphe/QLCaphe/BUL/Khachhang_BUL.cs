﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    class Khachhang_BUL
    {
        Khachhang_DAL kh_dal = new Khachhang_DAL();
        public DataTable load_khachhang()
        {
            return kh_dal.load_khachhang();
        }
        public int insert_khachhang(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.insert_khachhang(kh_public);
        }
        public int update_khachhang(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.update_khachhang(kh_public);
        }
        public int delete_khachhang(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.delete_khachhang(kh_public);
        }

        public int congtichluy(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.congtichluy(kh_public);
        }
        public DataTable Tim_kh(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.Tim_kh(kh_public);
        }
        public DataSet Loadtenkh(Khachhang_PUBLIC kh_public)
        {
            return kh_dal.Loadtenkh(kh_public);
        }
    }
}
