﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class Kho_BUL
    {
          Kho_DAL kho_dal = new Kho_DAL();
        public DataTable getAllMatHang()
        {
            return kho_dal.getAllMatHang();
        }
        public int InsertMatHang(Kho_PUBLIC kho_public)
        {
            return kho_dal.InsertMatHang(kho_public);
        }
        public int UpdateMathang(Kho_PUBLIC kho_public)
        {
            return kho_dal.UpdateMathang(kho_public);
        }
        public int DeleteMatHang(Kho_PUBLIC kho_public)
        {
            return kho_dal.DeleteMatHang(kho_public);
        }

       
        public DataTable FindMatHang(Kho_PUBLIC kho_public)
        {
            return kho_dal.FindMatHang(kho_public);
        }


        
    }
}
