﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class BillInfo_BUL
    {
        BillInfo_DAL billinfo_dal = new BillInfo_DAL();
        public DataTable load_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.load_billinfo(billinfo_public);
        }
        public int insert_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.insert_billinfo(billinfo_public);
        }
        public int update_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.update_billinfo(billinfo_public);
        }
        public int delete_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.delete_billinfo(billinfo_public);
        }
        public int load_idkh(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.load_idkh(billinfo_public);
        }
        public DataTable load_billinfo_thanhtoan(BillInfo_PUBLIC billinfo_public)
        {
            return billinfo_dal.load_billinfo_thanhtoan(billinfo_public);
        }
     
    }
}
