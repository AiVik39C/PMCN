﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class FoodCategory_BUL
    {
        FoodCategory_DAL dmdouong_dal = new FoodCategory_DAL();
        public DataSet load_dmdouong()
        {
            return dmdouong_dal.load_dmdouong();
        }
        public int insert_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            return dmdouong_dal.insert_dmdouong(dmdouong_public);
        }
        public int update_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            return dmdouong_dal.update_dmdouong(dmdouong_public);
        }
        public int delete_dmdouong(FoodCategory_PUBLIC dmdouong_public)
        {
            return dmdouong_dal.delete_dmdouong(dmdouong_public);
        }
    }
}
