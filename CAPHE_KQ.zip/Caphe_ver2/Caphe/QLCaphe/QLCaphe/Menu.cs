﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System.Data.SqlClient;
using System.Threading;
using System.Globalization;

namespace QLCaphe
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void xulybuttion(bool b)
        {
            btn_Them.Enabled = datagrid_danhmuc.Enabled = btn_tim.Enabled = btn_lammoi.Enabled = txt_tim.Enabled = btn_Sua.Enabled = btn_Xoa.Enabled = btn_Toi.Enabled = btn_Lui.Enabled = btn_thoat.Enabled = b;
            btn_Luu.Enabled = btn_Huy.Enabled = !b;
        }
        private bool nutThem = false, nutSua = false;
        private void dinhdangluoi()
        {
            datagrid_danhmuc.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            datagrid_danhmuc.Columns[0].HeaderText = "Mã";
            datagrid_danhmuc.Columns[1].HeaderText = "Tên";
            datagrid_danhmuc.Columns[2].HeaderText = "Danh mục";
            datagrid_danhmuc.Columns[3].HeaderText = "ID Danh mục";
            datagrid_danhmuc.Columns[4].HeaderText = "Đơn giá (VNĐ)";
            datagrid_danhmuc.Columns[4].DefaultCellStyle.Format = dinhdangso;
        }
        private void dinhdangluoi_inds()
        {
            string dinhdangso = "###,###,##0";
            datagrid_inds.ReadOnly = true;
            datagrid_inds.Columns[0].HeaderText = "Tên thực đơn";
            datagrid_inds.Columns[1].HeaderText = "Đơn giá";
            datagrid_inds.Columns[1].DefaultCellStyle.Format = dinhdangso;
        }

      
        private void cbiddm_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MNTDANHMUC_Click(object sender, EventArgs e)
        {

        }
        FoodCategory_BUL dmdouong_bul = new FoodCategory_BUL();
        Food_BUL douong_bul = new Food_BUL();
        private void Menu_Load(object sender, EventArgs e)
        {
            cb_tendm.DropDownStyle = ComboBoxStyle.DropDownList;
            DataSet dt = new DataSet();
            dt = dmdouong_bul.load_dmdouong();
            cb_tendm.DataSource = dt.Tables[0];
            cb_tendm.DisplayMember = "tendm";
            cb_tendm.ValueMember = "name";
            cbiddm.DataSource = dt.Tables[0];
            cbiddm.DisplayMember = "iddm";
            cbiddm.ValueMember = "id";
            cbiddm.Hide();
            xulybuttion(true);
            load_dsdouong();
            dinhdangluoi();
        }
        private void load_dsdouong()
        {
            bindingSource1.DataSource = douong_bul.load_food();
            datagrid_danhmuc.DataSource = bindingSource1;
        }
        private void insert()
        {
            Food_PUBLIC douong_public = new Food_PUBLIC();
            douong_public.id_dm = int.Parse(cbiddm.Text);
            douong_public.ten_food = txt_tendouong.Text;
            douong_public.dongia = float.Parse(txt_dongia.Text);
            douong_bul.insert_food(douong_public);
        }
        private void update()
        {
            Food_PUBLIC douong_public = new Food_PUBLIC();
            douong_public.idfood = int.Parse(txt_ma.Text);
            douong_public.id_dm = int.Parse(cbiddm.Text);
            douong_public.ten_food = txt_tendouong.Text;
            douong_public.dongia = float.Parse(txt_dongia.Text);
            douong_bul.update_food(douong_public);
        }
        private void delete()
        {
            Food_PUBLIC douong_public = new Food_PUBLIC();
            douong_public.idfood = int.Parse(txt_ma.Text);
            douong_bul.delete_food(douong_public);
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            nutThem = true;
            lbmasanpham.Hide();
            txt_ma.Hide();
            xulybuttion(false);
            txt_tendouong.Clear();
            txt_dongia.Text = "0";
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            nutSua = true;
            xulybuttion(false);
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (datagrid_danhmuc.Rows.Count == 1)
            { }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("Muốn xóa một món ăn?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    delete();
                    load_dsdouong();
                }
            }
        }

        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                if (txt_tendouong.TextLength == 0)
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa điền tên.";
                }
                else if (txt_dongia.TextLength == 0)
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa điền đơn giá.";
                }
                else if (cb_tendm.Text == "")
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa chọn danh mục.";
                }
                else
                {
                    insert();
                    nutThem = false;
                    xulybuttion(true);
                    load_dsdouong();
                }
            }
            else if (nutSua == true)
            {
                if (txt_tendouong.TextLength == 0)
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa điền tên.";
                }
                else if (txt_dongia.TextLength == 0)
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa điền đơn giá.";
                }
                else if (cb_tendm.Text == "")
                {
                    lbtrangthai.ForeColor = Color.DarkRed;
                    lbtrangthai.Text = "Chưa chọn danh mục.";
                }
                else
                {
                    update();
                    nutSua = false;
                    xulybuttion(true);
                    load_dsdouong();
                }
            }
        }

        private void btn_Huy_Click(object sender, EventArgs e)
        {

            if (nutThem == true)
            {
                nutThem = false;
                xulybuttion(true);
                load_dsdouong();
            }
            else if (nutSua == true)
            {
                nutSua = false;
                xulybuttion(true);
            }
        }

        private void btn_Lui_Click(object sender, EventArgs e)
        {
            try
            {
                int lui = datagrid_danhmuc.CurrentRow.Index - 1;
                if (lui != datagrid_danhmuc.Rows.Count + 1)
                {
                    datagrid_danhmuc.CurrentCell = datagrid_danhmuc.Rows[lui].Cells[datagrid_danhmuc.CurrentCell.ColumnIndex];
                    datagrid_danhmuc.Rows[lui].Selected = true;
                }
            }
            catch
            { }
        }

        private void btn_Toi_Click(object sender, EventArgs e)
        {
            try
            {
                int toi = datagrid_danhmuc.CurrentRow.Index + 1;
                if (toi != datagrid_danhmuc.Rows.Count - 1)
                {
                    datagrid_danhmuc.CurrentCell = datagrid_danhmuc.Rows[toi].Cells[datagrid_danhmuc.CurrentCell.ColumnIndex];
                    datagrid_danhmuc.Rows[toi].Selected = true;
                }
            }
            catch
            { }
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btn_tim_Click(object sender, EventArgs e)
        {
            if (txt_tim.TextLength == 0)
            {
                lbtrangthai.ForeColor = Color.DarkRed;
                lbtrangthai.Text = "Chưa điền tên cần tìm.";
            }
            else
            {
                Food_PUBLIC douong_public = new Food_PUBLIC();
                douong_public.ten_food = txt_tim.Text;
                datagrid_danhmuc.DataSource = douong_bul.TIM_Food(douong_public);
            }
        }

        private void btn_lammoi_Click(object sender, EventArgs e)
        {
            datagrid_danhmuc.DataSource = douong_bul.load_food();
        }

        private void txt_dongia_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double a = 0;
                a = double.Parse(txt_dongia.Text);
                txt_dongia.Text = a.ToString("###,###,##0");
            }
            catch
            { }   
        }



        int index;
        private void datagrid_danhmuc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            index = datagrid_danhmuc.CurrentRow.Index;
            txt_ma.Text = datagrid_danhmuc.Rows[index].Cells[0].Value.ToString();
            txt_tendouong.Text = datagrid_danhmuc.Rows[index].Cells[1].Value.ToString();
            cb_tendm.Text = datagrid_danhmuc.Rows[index].Cells[2].Value.ToString();
            cbiddm.Text = datagrid_danhmuc.Rows[index].Cells[3].Value.ToString();
            txt_dongia.Text = datagrid_danhmuc.Rows[index].Cells[4].Value.ToString();

        }

        private void datagrid_danhmuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = datagrid_danhmuc.CurrentRow.Index;
            txt_ma.Text = datagrid_danhmuc.Rows[index].Cells[0].Value.ToString();
            txt_tendouong.Text = datagrid_danhmuc.Rows[index].Cells[1].Value.ToString();
            cb_tendm.Text = datagrid_danhmuc.Rows[index].Cells[2].Value.ToString();
            cbiddm.Text = datagrid_danhmuc.Rows[index].Cells[3].Value.ToString();
            txt_dongia.Text = datagrid_danhmuc.Rows[index].Cells[4].Value.ToString();

        }

        private void cb_tendm_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
