﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class FoodCategory_PUBLIC
    {
        private int _iddm;

        public int iddm
        {
            get { return _iddm; }
            set { _iddm = value; }
        }
        private string _tendm;

        public string tendm
        {
            get { return _tendm; }
            set { _tendm = value; }
        }
    }
}
