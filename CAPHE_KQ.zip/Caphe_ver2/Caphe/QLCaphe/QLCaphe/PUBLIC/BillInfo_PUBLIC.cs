﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class BillInfo_PUBLIC
    {
        private int _id;

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        private int _idbill;

        public int idbill
        {
            get { return _idbill; }
            set { _idbill = value; }
        }

        private int _idban;

        public int idban
        {
            get { return _idban; }
            set { _idban = value; }
        }

        private int _idfood;

        public int idfood
        {
            get { return _idfood; }
            set { _idfood = value; }
        }

        private int _manv;

        public int manv
        {
            get { return _manv; }
            set { _manv = value; }
        }
        private int _idkh;

        public int idkh
        {
            get { return _idkh; }
            set { _idkh = value; }
        }

        private int _soluong;

        public int soluong
        {
            get { return _soluong; }
            set { _soluong = value; }
        }
    }
}
