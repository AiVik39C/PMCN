﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class BillInfo_OLD_PUBLIC
    {
        private int _idbillinfo_OLD;
        private int _idbill_OLD;
        private int _idfood;
        private int _soluong;

        public int idbillinfo_OLD
        {
            get
            {
                return _idbillinfo_OLD;
            }

            set
            {
                _idbillinfo_OLD = value;
            }
        }

        public int idbill_OLD
        {
            get
            {
                return _idbill_OLD;
            }

            set
            {
                _idbill_OLD = value;
            }
        }

        public int idfood
        {
            get
            {
                return _idfood;
            }

            set
            {
                _idfood = value;
            }
        }

        public int soluong
        {
            get
            {
                return _soluong;
            }

            set
            {
                _soluong = value;
            }
        }
    }
}
