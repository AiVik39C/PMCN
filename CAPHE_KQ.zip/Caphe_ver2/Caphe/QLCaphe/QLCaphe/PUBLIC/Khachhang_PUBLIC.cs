﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    class Khachhang_PUBLIC
    {
        private int _makh;

        public int makh
        {
            get { return _makh; }
            set { _makh = value; }
        }
        private string _TenKH;

        public string TenKH
        {
            get { return _TenKH; }
            set { _TenKH = value; }
        }
        private DateTime _Ngaysinh;

        public DateTime Ngaysinh
        {
            get { return _Ngaysinh; }
            set { _Ngaysinh = value; }
        }
        private string _Sodienthoai;

        public string Sodienthoai
        {
            get { return _Sodienthoai; }
            set { _Sodienthoai = value; }
        }
        private string _Gioitinh;

        public string Gioitinh
        {
            get { return _Gioitinh; }
            set { _Gioitinh = value; }
        }

        private float _tichluy;

        public float tichluy
        {
            get { return _tichluy; }
            set { _tichluy = value; }
        }

        private float _tongtien;

        public float tongtien
        {
            get { return _tongtien; }
            set { _tongtien = value; }
        }
        private string _TIMTEN;

        public string TIMTEN
        {
            get { return _TIMTEN; }
            set { _TIMTEN = value; }
        }
    }
}
