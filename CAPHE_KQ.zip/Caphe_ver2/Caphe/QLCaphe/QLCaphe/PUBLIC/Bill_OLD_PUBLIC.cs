﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class Bill_OLD_PUBLIC
    {
        private int _id_OLD;
        private int _idbill;
        private int _idban;
        private int _manv;
        DateTime _Ngaylap;
        private string _Trangthai;
        private double _Tongtien;
        private string _soban;
        private int _Ngay;
        private int _Thang;
        private int _Nam;
        private string _TenNV;
        public int id_OLD
        {
            get
            {
                return _id_OLD;
            }

            set
            {
                _id_OLD = value;
            }
        }

        public int idbill
        {
            get
            {
                return _idbill;
            }

            set
            {
                _idbill = value;
            }
        }

        public int idban
        {
            get
            {
                return _idban;
            }

            set
            {
                _idban = value;
            }
        }

        public int manv
        {
            get
            {
                return _manv;
            }

            set
            {
                _manv = value;
            }
        }

        public DateTime Ngaylap
        {
            get
            {
                return _Ngaylap;
            }

            set
            {
                _Ngaylap = value;
            }
        }

        public string Trangthai
        {
            get
            {
                return _Trangthai;
            }

            set
            {
                _Trangthai = value;
            }
        }

        public double Tongtien
        {
            get
            {
                return _Tongtien;
            }

            set
            {
                _Tongtien = value;
            }
        }

        public string soban
        {
            get
            {
                return _soban;
            }

            set
            {
                _soban = value;
            }
        }

        public int Ngay
        {
            get
            {
                return _Ngay;
            }

            set
            {
                _Ngay = value;
            }
        }

        public int Thang
        {
            get
            {
                return _Thang;
            }

            set
            {
                _Thang = value;
            }
        }

        public int Nam
        {
            get
            {
                return _Nam;
            }

            set
            {
                _Nam = value;
            }
        }

        public string TenNV
        {
            get
            {
                return _TenNV;
            }

            set
            {
                _TenNV = value;
            }
        }
    }
}
