﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class Food_PUBLIC
    {
        private int _idfood;

        public int idfood
        {
            get { return _idfood; }
            set { _idfood = value; }
        }
        private int _id_dm;

        public int id_dm
        {
            get { return _id_dm; }
            set { _id_dm = value; }
        }
        private string _ten_food;

        public string ten_food
        {
            get { return _ten_food; }
            set { _ten_food = value; }
        }
        private float _dongia;

        public float dongia
        {
            get { return _dongia; }
            set { _dongia = value; }
        }

        public string ten
        {
            get
            {
                return _ten;
            }

            set
            {
                _ten = value;
            }
        }

        private string _ten;
    
    }
}
