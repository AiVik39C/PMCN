﻿namespace QLCaphe
{
    partial class Ban_Danhmuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ban_Danhmuc));
            this.DSMON = new System.Windows.Forms.GroupBox();
            this.datagrid_mon = new System.Windows.Forms.DataGridView();
            this.THUCDON = new System.Windows.Forms.GroupBox();
            this.cbidkh = new System.Windows.Forms.ComboBox();
            this.cbkh = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_gopban = new System.Windows.Forms.Button();
            this.cbten = new System.Windows.Forms.ComboBox();
            this.cbgia = new System.Windows.Forms.ComboBox();
            this.btn_thanhtoan = new System.Windows.Forms.Button();
            this.btn_chuyenban = new System.Windows.Forms.Button();
            this.btn_Xoa = new System.Windows.Forms.Button();
            this.btn_Them = new System.Windows.Forms.Button();
            this.numericsoluongdoan = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cbdanhmuc = new System.Windows.Forms.ComboBox();
            this.foodCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cAPHEDataSet = new QLCaphe.CAPHEDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbiddouong = new System.Windows.Forms.ComboBox();
            this.dg_dsban = new System.Windows.Forms.DataGridView();
            this.bt_themban = new System.Windows.Forms.Button();
            this.cbiddm = new System.Windows.Forms.ComboBox();
            this.Soban = new System.Windows.Forms.NumericUpDown();
            this.lbthemban = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.foodCategoryTableAdapter = new QLCaphe.CAPHEDataSetTableAdapters.FoodCategoryTableAdapter();
            this.DSMON.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_mon)).BeginInit();
            this.THUCDON.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericsoluongdoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAPHEDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dsban)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Soban)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // DSMON
            // 
            this.DSMON.BackColor = System.Drawing.Color.Transparent;
            this.DSMON.Controls.Add(this.datagrid_mon);
            this.DSMON.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.DSMON.ForeColor = System.Drawing.Color.Red;
            this.DSMON.Location = new System.Drawing.Point(436, 159);
            this.DSMON.Name = "DSMON";
            this.DSMON.Size = new System.Drawing.Size(705, 416);
            this.DSMON.TabIndex = 8;
            this.DSMON.TabStop = false;
            this.DSMON.Text = "Danh sách món ăn của ";
            // 
            // datagrid_mon
            // 
            this.datagrid_mon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagrid_mon.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.datagrid_mon.BackgroundColor = System.Drawing.SystemColors.Control;
            this.datagrid_mon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagrid_mon.DefaultCellStyle = dataGridViewCellStyle1;
            this.datagrid_mon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datagrid_mon.EnableHeadersVisualStyles = false;
            this.datagrid_mon.Location = new System.Drawing.Point(3, 20);
            this.datagrid_mon.Name = "datagrid_mon";
            this.datagrid_mon.Size = new System.Drawing.Size(699, 393);
            this.datagrid_mon.TabIndex = 0;
            // 
            // THUCDON
            // 
            this.THUCDON.BackColor = System.Drawing.Color.Transparent;
            this.THUCDON.Controls.Add(this.cbidkh);
            this.THUCDON.Controls.Add(this.cbkh);
            this.THUCDON.Controls.Add(this.label4);
            this.THUCDON.Controls.Add(this.btn_gopban);
            this.THUCDON.Controls.Add(this.cbten);
            this.THUCDON.Controls.Add(this.cbgia);
            this.THUCDON.Controls.Add(this.btn_thanhtoan);
            this.THUCDON.Controls.Add(this.btn_chuyenban);
            this.THUCDON.Controls.Add(this.btn_Xoa);
            this.THUCDON.Controls.Add(this.btn_Them);
            this.THUCDON.Controls.Add(this.numericsoluongdoan);
            this.THUCDON.Controls.Add(this.label3);
            this.THUCDON.Controls.Add(this.cbdanhmuc);
            this.THUCDON.Controls.Add(this.label2);
            this.THUCDON.Controls.Add(this.label1);
            this.THUCDON.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.THUCDON.ForeColor = System.Drawing.Color.Red;
            this.THUCDON.Location = new System.Drawing.Point(438, 4);
            this.THUCDON.Name = "THUCDON";
            this.THUCDON.Size = new System.Drawing.Size(703, 149);
            this.THUCDON.TabIndex = 7;
            this.THUCDON.TabStop = false;
            this.THUCDON.Text = "Chọn thực đơn";
            // 
            // cbidkh
            // 
            this.cbidkh.FormattingEnabled = true;
            this.cbidkh.Location = new System.Drawing.Point(266, 112);
            this.cbidkh.Name = "cbidkh";
            this.cbidkh.Size = new System.Drawing.Size(34, 26);
            this.cbidkh.TabIndex = 20;
            // 
            // cbkh
            // 
            this.cbkh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbkh.FormattingEnabled = true;
            this.cbkh.Location = new System.Drawing.Point(92, 113);
            this.cbkh.Name = "cbkh";
            this.cbkh.Size = new System.Drawing.Size(157, 26);
            this.cbkh.TabIndex = 19;
            this.cbkh.Click += new System.EventHandler(this.cbkh_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(6, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 18);
            this.label4.TabIndex = 18;
            this.label4.Text = "Khách hàng:";
            // 
            // btn_gopban
            // 
            this.btn_gopban.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_gopban.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_gopban.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_gopban.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_gopban.Image = global::QLCaphe.Properties.Resources.BTTOI__2_;
            this.btn_gopban.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_gopban.Location = new System.Drawing.Point(422, 24);
            this.btn_gopban.Name = "btn_gopban";
            this.btn_gopban.Size = new System.Drawing.Size(77, 80);
            this.btn_gopban.TabIndex = 17;
            this.btn_gopban.Text = "Gộp bàn";
            this.btn_gopban.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_gopban.UseVisualStyleBackColor = true;
            this.btn_gopban.Click += new System.EventHandler(this.btn_gopban_Click);
            // 
            // cbten
            // 
            this.cbten.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cbten.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbten.FormattingEnabled = true;
            this.cbten.Location = new System.Drawing.Point(92, 51);
            this.cbten.Name = "cbten";
            this.cbten.Size = new System.Drawing.Size(157, 26);
            this.cbten.TabIndex = 16;
            this.cbten.Click += new System.EventHandler(this.cbten_Click);
            // 
            // cbgia
            // 
            this.cbgia.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cbgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbgia.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbgia.FormatString = "C0";
            this.cbgia.FormattingEnabled = true;
            this.cbgia.Location = new System.Drawing.Point(154, 83);
            this.cbgia.Name = "cbgia";
            this.cbgia.Size = new System.Drawing.Size(95, 26);
            this.cbgia.TabIndex = 14;
            // 
            // btn_thanhtoan
            // 
            this.btn_thanhtoan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_thanhtoan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_thanhtoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_thanhtoan.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_thanhtoan.Image = global::QLCaphe.Properties.Resources.BTTOI__11_;
            this.btn_thanhtoan.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_thanhtoan.Location = new System.Drawing.Point(605, 24);
            this.btn_thanhtoan.Name = "btn_thanhtoan";
            this.btn_thanhtoan.Size = new System.Drawing.Size(78, 80);
            this.btn_thanhtoan.TabIndex = 12;
            this.btn_thanhtoan.Text = "Thanh toán";
            this.btn_thanhtoan.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_thanhtoan.UseVisualStyleBackColor = true;
            this.btn_thanhtoan.Click += new System.EventHandler(this.btn_thanhtoan_Click);
            // 
            // btn_chuyenban
            // 
            this.btn_chuyenban.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_chuyenban.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_chuyenban.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_chuyenban.Image = global::QLCaphe.Properties.Resources.BTTOI__12_;
            this.btn_chuyenban.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_chuyenban.Location = new System.Drawing.Point(514, 23);
            this.btn_chuyenban.Name = "btn_chuyenban";
            this.btn_chuyenban.Size = new System.Drawing.Size(76, 81);
            this.btn_chuyenban.TabIndex = 11;
            this.btn_chuyenban.Text = "Chuyển bàn";
            this.btn_chuyenban.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_chuyenban.UseVisualStyleBackColor = true;
            this.btn_chuyenban.Click += new System.EventHandler(this.btn_chuyenban_Click);
            // 
            // btn_Xoa
            // 
            this.btn_Xoa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Xoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_Xoa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_Xoa.Image = global::QLCaphe.Properties.Resources.BTTOI__1_;
            this.btn_Xoa.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Xoa.Location = new System.Drawing.Point(342, 24);
            this.btn_Xoa.Name = "btn_Xoa";
            this.btn_Xoa.Size = new System.Drawing.Size(64, 80);
            this.btn_Xoa.TabIndex = 10;
            this.btn_Xoa.Text = "Xóa";
            this.btn_Xoa.UseVisualStyleBackColor = true;
            this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Them.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_Them.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_Them.Image = global::QLCaphe.Properties.Resources.BTTOI__14_;
            this.btn_Them.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Them.Location = new System.Drawing.Point(266, 24);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(61, 80);
            this.btn_Them.TabIndex = 9;
            this.btn_Them.Text = "Thêm";
            this.btn_Them.UseVisualStyleBackColor = true;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // numericsoluongdoan
            // 
            this.numericsoluongdoan.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.numericsoluongdoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.numericsoluongdoan.ForeColor = System.Drawing.SystemColors.ControlText;
            this.numericsoluongdoan.Location = new System.Drawing.Point(92, 84);
            this.numericsoluongdoan.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numericsoluongdoan.Name = "numericsoluongdoan";
            this.numericsoluongdoan.Size = new System.Drawing.Size(56, 24);
            this.numericsoluongdoan.TabIndex = 8;
            this.numericsoluongdoan.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Số lượng:";
            // 
            // cbdanhmuc
            // 
            this.cbdanhmuc.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cbdanhmuc.DataSource = this.foodCategoryBindingSource;
            this.cbdanhmuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbdanhmuc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbdanhmuc.FormattingEnabled = true;
            this.cbdanhmuc.Location = new System.Drawing.Point(92, 21);
            this.cbdanhmuc.Name = "cbdanhmuc";
            this.cbdanhmuc.Size = new System.Drawing.Size(157, 26);
            this.cbdanhmuc.TabIndex = 2;
            this.cbdanhmuc.SelectedIndexChanged += new System.EventHandler(this.cbdanhmuc_SelectedIndexChanged);
            // 
            // foodCategoryBindingSource
            // 
            this.foodCategoryBindingSource.DataMember = "FoodCategory";
            this.foodCategoryBindingSource.DataSource = this.cAPHEDataSet;
            // 
            // cAPHEDataSet
            // 
            this.cAPHEDataSet.DataSetName = "CAPHEDataSet";
            this.cAPHEDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(6, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên món:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(6, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Danh mục:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.cbiddouong);
            this.groupBox1.Controls.Add(this.dg_dsban);
            this.groupBox1.Controls.Add(this.bt_themban);
            this.groupBox1.Controls.Add(this.cbiddm);
            this.groupBox1.Controls.Add(this.Soban);
            this.groupBox1.Controls.Add(this.lbthemban);
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(7, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 571);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sơ đồ bàn";
            // 
            // cbiddouong
            // 
            this.cbiddouong.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbiddouong.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbiddouong.FormattingEnabled = true;
            this.cbiddouong.Location = new System.Drawing.Point(254, 14);
            this.cbiddouong.Name = "cbiddouong";
            this.cbiddouong.Size = new System.Drawing.Size(34, 26);
            this.cbiddouong.TabIndex = 14;
            // 
            // dg_dsban
            // 
            this.dg_dsban.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dg_dsban.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_dsban.Location = new System.Drawing.Point(348, 22);
            this.dg_dsban.Name = "dg_dsban";
            this.dg_dsban.Size = new System.Drawing.Size(24, 16);
            this.dg_dsban.TabIndex = 7;
            // 
            // bt_themban
            // 
            this.bt_themban.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt_themban.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt_themban.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bt_themban.Location = new System.Drawing.Point(181, 16);
            this.bt_themban.Name = "bt_themban";
            this.bt_themban.Size = new System.Drawing.Size(67, 22);
            this.bt_themban.TabIndex = 6;
            this.bt_themban.Text = "Thêm";
            this.bt_themban.UseVisualStyleBackColor = true;
            this.bt_themban.Click += new System.EventHandler(this.bt_themban_Click);
            // 
            // cbiddm
            // 
            this.cbiddm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbiddm.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbiddm.FormattingEnabled = true;
            this.cbiddm.Location = new System.Drawing.Point(286, 14);
            this.cbiddm.Name = "cbiddm";
            this.cbiddm.Size = new System.Drawing.Size(34, 26);
            this.cbiddm.TabIndex = 13;
            // 
            // Soban
            // 
            this.Soban.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Soban.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Soban.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Soban.Location = new System.Drawing.Point(118, 16);
            this.Soban.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.Soban.Name = "Soban";
            this.Soban.Size = new System.Drawing.Size(57, 22);
            this.Soban.TabIndex = 5;
            this.Soban.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lbthemban
            // 
            this.lbthemban.AutoSize = true;
            this.lbthemban.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbthemban.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbthemban.Location = new System.Drawing.Point(22, 18);
            this.lbthemban.Name = "lbthemban";
            this.lbthemban.Size = new System.Drawing.Size(90, 16);
            this.lbthemban.TabIndex = 4;
            this.lbthemban.Text = "Thêm số bàn:";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.SystemColors.Control;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.flowLayoutPanel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 44);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(411, 524);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // foodCategoryTableAdapter
            // 
            this.foodCategoryTableAdapter.ClearBeforeFill = true;
            // 
            // Ban_Danhmuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 580);
            this.Controls.Add(this.DSMON);
            this.Controls.Add(this.THUCDON);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Ban_Danhmuc";
            this.Text = "Thông tin và sơ đồ bàn";
            this.Load += new System.EventHandler(this.Ban_Danhmuc_Load_1);
            this.DSMON.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_mon)).EndInit();
            this.THUCDON.ResumeLayout(false);
            this.THUCDON.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericsoluongdoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAPHEDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dsban)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Soban)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.GroupBox DSMON;
        public System.Windows.Forms.DataGridView datagrid_mon;
        private System.Windows.Forms.GroupBox THUCDON;
        private System.Windows.Forms.Button btn_gopban;
        private System.Windows.Forms.ComboBox cbten;
        private System.Windows.Forms.ComboBox cbgia;
        private System.Windows.Forms.Button btn_thanhtoan;
        private System.Windows.Forms.Button btn_chuyenban;
        private System.Windows.Forms.Button btn_Xoa;
        private System.Windows.Forms.Button btn_Them;
        private System.Windows.Forms.NumericUpDown numericsoluongdoan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbdanhmuc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbiddouong;
        private System.Windows.Forms.DataGridView dg_dsban;
        private System.Windows.Forms.Button bt_themban;
        private System.Windows.Forms.ComboBox cbiddm;
        private System.Windows.Forms.NumericUpDown Soban;
        private System.Windows.Forms.Label lbthemban;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private CAPHEDataSet cAPHEDataSet;
        private System.Windows.Forms.BindingSource foodCategoryBindingSource;
        private CAPHEDataSetTableAdapters.FoodCategoryTableAdapter foodCategoryTableAdapter;
        private System.Windows.Forms.ComboBox cbkh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbidkh;
    }
}