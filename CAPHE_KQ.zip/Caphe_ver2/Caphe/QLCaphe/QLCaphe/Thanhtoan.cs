﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Thanhtoan : Form
    {
       
        public static Thanhtoan thanhtoan;
        public Thanhtoan()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
            thanhtoan = this;
        }
        private int IDBAN;

        public int idban
        {
            get
            {
                return IDBAN;
            }

            set
            {
                IDBAN = value;
            }
        }

        public string tenban
        {
            get
            {
                return TENBAN;
            }

            set
            {
                TENBAN = value;
            }
        }
        private int IDNV;
        public int idnv
        {
            get
            {
                return IDNV;
            }

            set
            {
                IDNV = value;
            }
        }

        private string TENBAN;
        int idbill = 0;
        Bill_BUL bill_bul = new Bill_BUL();
        BillInfo_BUL billinfo_bul = new BillInfo_BUL();
        Ban_BUL ban_bul = new Ban_BUL();
        int manv = 0;
        int makh = 0;
        private void Thanhtoan_Load(object sender, EventArgs e)
        {
            txt_tongtien.ReadOnly = true;
            groupBoxhd.Text = "Hóa đơn " + tenban;
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.idban = idban;
           
            Load_BillInfo(idban);
            tinhtongtien();           
        }
        private void Load_BillInfo(int idban)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.idban = idban;
            bindingSource1.DataSource = billinfo_bul.load_billinfo_thanhtoan(billinfo_public);
            datagrid_mon.DataSource = bindingSource1;
            dinhdangluoi();
        }
        private void dinhdangluoi()
        {
            datagrid_mon.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            datagrid_mon.Columns[0].HeaderText = "Mã đồ uống";
            datagrid_mon.Columns[1].HeaderText = "Tên món";
            datagrid_mon.Columns[2].HeaderText = "Số lượng";
            datagrid_mon.Columns[3].HeaderText = "Đơn giá (VNĐ)";
            datagrid_mon.Columns[3].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[4].HeaderText = "Thành tiền (VNĐ)";
            datagrid_mon.Columns[4].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[5].HeaderText = "Danh mục";
        }
        private void tinhtongtien()
        {
           

                double tongtien = 0;
                for (int i = 0; i < datagrid_mon.Rows.Count-1; ++i)
                {
                    tongtien += Convert.ToDouble(datagrid_mon.Rows[i].Cells[4].Value.ToString());
                }
                txt_tongtien.Text = tongtien.ToString("###,###,##0");
                
        }

     
        private void dongform()
        {
            this.Close();
        }
      
        public  void Thanhtoan_FormClosing(object sender, FormClosingEventArgs e)
        {
          //
        }


        Bill_OLD_BUL bill_old_bul = new Bill_OLD_BUL();
        Khachhang_BUL kh_bul = new Khachhang_BUL();
        BillInfo_OLD_BUL billinfo_old_bul = new BillInfo_OLD_BUL();
        private void btn_thanhtoan_Click(object sender, EventArgs e)
        {
            Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.idban = idban;
            idbill = bill_bul.load_id_with_idban(bill_public);
            bill_public.id = idbill;
            manv = bill_bul.load_idnv(bill_public);
            //
            Bill_OLD_PUBLIC bill_old_public = new Bill_OLD_PUBLIC();
            bill_old_public.idbill = idbill;
            bill_old_public.idban = IDBAN;
            bill_old_public.manv = manv;
            bill_old_public.Ngaylap = DateTime.Now;
            bill_old_public.Trangthai = "Thanh toán";
            bill_old_public.Tongtien = double.Parse(txt_tongtien.Text);
            //
            billinfo_public.idbill = idbill;
            makh = billinfo_bul.load_idkh(billinfo_public);
            kh_public.makh = makh;
             kh_public.tongtien=float.Parse(txt_tongtien.Text);
             kh_bul.congtichluy(kh_public);
            bill_old_bul.insert_bill_old(bill_old_public);
            //
            BillInfo_OLD_PUBLIC billinfo_old_public = new BillInfo_OLD_PUBLIC();
            for (int i = 0; i < datagrid_mon.Rows.Count - 1; i++)
            {
                billinfo_old_public.idbill_OLD = idbill;
                billinfo_old_public.idfood = int.Parse(datagrid_mon[0, i].Value.ToString());
                billinfo_old_public.soluong = int.Parse(datagrid_mon[2, i].Value.ToString());
                billinfo_old_bul.insert_billinfo_old(billinfo_old_public);
            }
            // delete CTHD 
            for (int j = 0; j < datagrid_mon.Rows.Count - 1; j++)
            {
                billinfo_public.idbill = idbill;
                billinfo_public.idfood = int.Parse(datagrid_mon[0, j].Value.ToString());
                billinfo_bul.delete_billinfo(billinfo_public);
            }
           
            bill_public.id = idbill;
            bill_bul.delete_bill(bill_public);
            // update trạng thái bàn
            Ban_PUBLIC ban_public = new Ban_PUBLIC();
            ban_public.IDBAN = idban;
            ban_public.TRANGTHAI = "Trống";
            ban_bul.update_trangthaiban(ban_public);
            Ban_Danhmuc ban = new Ban_Danhmuc();
            this.Close();
        }
    }
       
 }

