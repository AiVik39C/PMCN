﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Khachhang : Form
    {
        public Khachhang()
        {
            InitializeComponent();
        }

        private void xulybuttion(bool b)
        {
            btn_Them.Enabled = datagrid_khachhang.Enabled = btn_tim.Enabled = btn_lammoi.Enabled = txt_tim.Enabled = btn_Sua.Enabled = btn_Xoa.Enabled = btn_Toi.Enabled = btn_Lui.Enabled = btn_Thoat.Enabled = b;
            btn_Luu.Enabled = btn_Huy.Enabled = !b;
        }
        private bool nutThem = false, nutSua = false;
       


        Khachhang_BUL kh_bul = new Khachhang_BUL();
    

        private void LoadDataGrid()
        {
            bindingSource1.DataSource = kh_bul.load_khachhang();
            datagrid_khachhang.DataSource = bindingSource1;
        }
        private void EditDataGrid()
        {
            datagrid_khachhang.ReadOnly = true;
            datagrid_khachhang.Columns[0].HeaderText = "Mã khách hàng";
            datagrid_khachhang.Columns[1].HeaderText = "Tên khách hàng";
            datagrid_khachhang.Columns[2].HeaderText = "Ngày sinh";
            datagrid_khachhang.Columns[3].HeaderText = "Số điện thoại";
            datagrid_khachhang.Columns[4].HeaderText = "Giới tính";
            datagrid_khachhang.Columns[5].HeaderText = "Tichs lũy";

        }

        private void datagrid_khachhang_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int dong = e.RowIndex;
            txt_makh.Text = datagrid_khachhang.Rows[dong].Cells[0].Value.ToString();
            txt_tenkh.Text = datagrid_khachhang.Rows[dong].Cells[1].Value.ToString();
            date_ngaysinh.Text = datagrid_khachhang.Rows[dong].Cells[2].Value.ToString();
            txt_sdt.Text = datagrid_khachhang.Rows[dong].Cells[3].Value.ToString();
            cb_gioitinh.Text = datagrid_khachhang.Rows[dong].Cells[4].Value.ToString();
            txt_tichluy.Text = datagrid_khachhang.Rows[dong].Cells[5].Value.ToString();


        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            nutThem = true;
            txt_makh.Hide();
            xulybuttion(false);
            txt_tenkh.Focus();
            Clear();
        }
        private void Clear()
        {
            txt_tenkh.Clear();
            date_ngaysinh.ResetText();
            txt_sdt.Clear();
            cb_gioitinh.SelectedIndex = -1;
            txt_tichluy.Clear();

        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

       
        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Muốn xóa một khách hàng?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {


                DeleteKhachHang();
                LoadDataGrid();
            }
        }

        private void DeleteKhachHang()
        {
            Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
            kh_public.makh = int.Parse(txt_makh.Text);
            kh_bul.delete_khachhang(kh_public);
        }
        private void InsertKhachHang()
        {
            Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
            kh_public.TenKH = txt_tenkh.Text;
            kh_public.Ngaysinh = DateTime.Parse(date_ngaysinh.Text);
            kh_public.Sodienthoai = txt_sdt.Text;
            kh_public.Gioitinh = cb_gioitinh.Text;
            kh_public.tichluy = float.Parse(txt_tichluy.Text) ;
            kh_bul.insert_khachhang(kh_public);
        }

        private void UpdateKhachHang()
        {
            Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
            kh_public.makh = kh_public.makh = int.Parse(txt_makh.Text);
            kh_public.TenKH = txt_tenkh.Text;
            kh_public.Ngaysinh = DateTime.Parse(date_ngaysinh.Text);
            kh_public.Sodienthoai = txt_sdt.Text;
            kh_public.Gioitinh = cb_gioitinh.Text;
            kh_public.tichluy = float.Parse(txt_tichluy.Text);
            kh_bul.update_khachhang(kh_public);
        }

        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                if (txt_tenkh.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên khách hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (date_ngaysinh.Value.Year == DateTime.Today.Year)
                {
                    MessageBox.Show("Chưa chọn ngày sinh.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                //else if (txtsdt.TextLength == 0)
                //{
                //    MessageBox.Show("Chưa nhập số điện thoại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}
                else if (cb_gioitinh.Text == "")
                {
                    MessageBox.Show("Chưa chọn giới tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tichluy.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền số tích lũy.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
              

                else if (txt_tenkh.TextLength >= 100)
                {
                    MessageBox.Show("Tên nhân viên quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_sdt.TextLength >= 11)
                {
                    MessageBox.Show("Số điện thoại quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
             
                else
                {
                    try
                    {
                        nutThem = false;
                        InsertKhachHang();
                        LoadDataGrid();
                        xulybuttion(true);
                    }
                    catch
                    {
                    }
                }
            }
            else if (nutSua == true)
            {
                if (txt_tenkh.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên khách hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (date_ngaysinh.Value.Year == DateTime.Today.Year)
                {
                    MessageBox.Show("Chưa chọn ngày sinh.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                //else if (txtsdt.TextLength == 0)
                //{
                //    MessageBox.Show("Chưa nhập số điện thoại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}
                else if (cb_gioitinh.Text == "")
                {
                    MessageBox.Show("Chưa chọn giới tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tichluy.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền số tích lũy.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


                else if (txt_tenkh.TextLength >= 100)
                {
                    MessageBox.Show("Tên nhân viên quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_sdt.TextLength >= 11)
                {
                    MessageBox.Show("Số điện thoại quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {

                    UpdateKhachHang();
                    xulybuttion(true);
                    nutSua = false;
                    LoadDataGrid();
                }
            }
        }

        private void btn_Huy_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                //
                LoadDataGrid();
                xulybuttion(true);
                nutThem = false;
            }
            else if (nutSua == true)
            {
                //
                xulybuttion(true);
                nutSua = false;
            }
        }

        private void btn_Lui_Click(object sender, EventArgs e)
        {
            try
            {
                int lui = datagrid_khachhang.CurrentRow.Index - 1;
                if (lui != datagrid_khachhang.Rows.Count + 1)
                {
                    datagrid_khachhang.CurrentCell = datagrid_khachhang.Rows[lui].Cells[datagrid_khachhang.CurrentCell.ColumnIndex];
                    datagrid_khachhang.Rows[lui].Selected = true;
                }
            }
            catch
            { }
        }

        private void btn_Toi_Click(object sender, EventArgs e)
        {
            try
            {
                int toi = datagrid_khachhang.CurrentRow.Index + 1;
                if (toi != datagrid_khachhang.Rows.Count - 1)
                {
                    datagrid_khachhang.CurrentCell = datagrid_khachhang.Rows[toi].Cells[datagrid_khachhang.CurrentCell.ColumnIndex];
                    datagrid_khachhang.Rows[toi].Selected = true;
                }
            }
            catch
            { }
        }

        private void btn_tim_Click(object sender, EventArgs e)
        {
            if (txt_tim.TextLength == 0)
            {
                MessageBox.Show("Chưa nhập tên khách hàng cần tìm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
                kh_public.TIMTEN = txt_tim.Text;
                datagrid_khachhang.DataSource = kh_bul.Tim_kh(kh_public);
                //datagrid_khachhang.Rows[0].Selected = true;
            }
        }

        private void btn_lammoi_Click(object sender, EventArgs e)
        {

            datagrid_khachhang.DataSource = kh_bul.load_khachhang();
            txt_tim.Clear();
        }

        private void ChiDuocNhapSo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // chỉ cho phép dấu thập phân
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void sdt_keyPress(object sender, KeyPressEventArgs e)
        {
            ChiDuocNhapSo(sender, e);
        }
        int index;
        private void datagrid_nhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            index = datagrid_khachhang.CurrentRow.Index;
            txt_makh.Text = datagrid_khachhang.Rows[index].Cells[0].Value.ToString();
            txt_tenkh.Text = datagrid_khachhang.Rows[index].Cells[1].Value.ToString();
            date_ngaysinh.Text = datagrid_khachhang.Rows[index].Cells[2].Value.ToString();
            txt_sdt.Text = datagrid_khachhang.Rows[index].Cells[3].Value.ToString();
            cb_gioitinh.Text = datagrid_khachhang.Rows[index].Cells[4].Value.ToString();
            txt_tichluy.Text = datagrid_khachhang.Rows[index].Cells[5].Value.ToString();

        }

        private void datagrid_khachhang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = datagrid_khachhang.CurrentRow.Index;
            txt_makh.Text = datagrid_khachhang.Rows[index].Cells[0].Value.ToString();
            txt_tenkh.Text = datagrid_khachhang.Rows[index].Cells[1].Value.ToString();
            date_ngaysinh.Text = datagrid_khachhang.Rows[index].Cells[2].Value.ToString();
            txt_sdt.Text = datagrid_khachhang.Rows[index].Cells[3].Value.ToString();
            cb_gioitinh.Text = datagrid_khachhang.Rows[index].Cells[4].Value.ToString();
            txt_tichluy.Text = datagrid_khachhang.Rows[index].Cells[5].Value.ToString();
        }

        private void Khachhang_Load_1(object sender, EventArgs e)
        {
            xulybuttion(true);
            LoadDataGrid();
            EditDataGrid();
        }

        private void btn_Sua_Click_1(object sender, EventArgs e)
        {
            nutSua = true;
            txt_makh.Hide();
            xulybuttion(false);
        }
    }
}
