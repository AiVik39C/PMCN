﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QLCaphe
{
    public partial class Ban_Danhmuc : Form
    {
        public static Ban_Danhmuc formban_dm;
        public Ban_Danhmuc()
        {
            InitializeComponent();
        }

        Ban_BUL ban_bul = new Ban_BUL();
        internal void taobanan()
        {

            flowLayoutPanel1.Controls.Clear();// làm mới sơ đồ bàn
            List<Ban_PUBLIC> dsban = ban_bul.Loaddsban();
            foreach (Ban_PUBLIC dong in dsban)
            {
                Button bt = new Button();
                bt.Click += bt_click;// tạo sự kiện click cho button
                bt.Tag = dong; // dùng để xác định ID của mỗi button
                bt.Width = 90;
                bt.Height = 90;
                bt.Text = dong.TEN + "\n" + dong.TRANGTHAI;
                if (dong.TRANGTHAI == "Trống")
                {
                    bt.BackColor = Color.Yellow;
                    flowLayoutPanel1.Controls.Add(bt);
                }
               else if (dong.TRANGTHAI == "Có người")
                {
                    bt.BackColor = Color.OrangeRed;
                    flowLayoutPanel1.Controls.Add(bt);
                }
               
            }
        }

        Bill_BUL bill_bul = new Bill_BUL();
        BillInfo_BUL billinfo_bul = new BillInfo_BUL();
        int idbill = 0;
        int idban = 0;
        string tenban = "";
        int idnv;
        string trangthaiban = "";
       
        private void bt_click(object sender, EventArgs e)
        {
            idban = ((sender as Button).Tag as Ban_PUBLIC).IDBAN;
            tenban = ((sender as Button).Tag as Ban_PUBLIC).TEN;
            trangthaiban = ((sender as Button).Tag as Ban_PUBLIC).TRANGTHAI;
            DSMON.Text = "Danh sách món ăn của " + tenban;
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.idban = idban;
            int sohoadonban = bill_bul.count_bill_ban(bill_public);
            if (sohoadonban == 0)
            {
                bill_public.idnv = Idnv;// lấy từ mã từ tài khoản nhân viên đăng nhập vào
                bill_public.dateCheckin = DateTime.Now;
                bill_public.dateCheckout = DateTime.Now;
                bill_public.trangthai = "Chưa";
                bill_bul.load_bill();
                taobanan();
                Load_CTHD(idban);
            }
            else
            {

               // idbill = bill_bul.load_id_with_idban(bill_public);
                Load_CTHD(idban);
                numericsoluongdoan.Value = 1;
               
                
            }
              
                
            
           
        }

      
        private void btn_thanhtoan_Click(object sender, EventArgs e)
        {
            if (datagrid_mon.Rows.Count == 0)
            {
                MessageBox.Show("Chọn một bàn rồi mới thanh toán hóa đơn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (datagrid_mon.Rows.Count == 1)
            {
                MessageBox.Show("Bàn chưa có món, không thể thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Thanhtoan tt = new Thanhtoan();
                tt.idban = idban;
                tt.tenban= tenban;
                tt.idnv = this.Idnv;
                tt.FormClosing += new FormClosingEventHandler(tt.Thanhtoan_FormClosing);
                tt.ShowDialog();
            }
        }
        internal void Load_BillInfo(int idban)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.idban = idban;
            bindingSource1.DataSource = billinfo_bul.load_billinfo(billinfo_public);
            datagrid_mon.DataSource = bindingSource1;
            dinhdangluoi();
        }
        private void dinhdangluoi()
        {
            datagrid_mon.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            datagrid_mon.Columns[0].HeaderText = "ID ";
            datagrid_mon.Columns[1].HeaderText = "ID Bill";
            datagrid_mon.Columns[2].HeaderText = "Tên bàn";
            datagrid_mon.Columns[3].HeaderText = "Tên NV";
            datagrid_mon.Columns[4].HeaderText = "Tên KH";
            datagrid_mon.Columns[5].HeaderText = "FoodCategory";
            datagrid_mon.Columns[6].HeaderText = "Tên món";
            datagrid_mon.Columns[7].HeaderText = "Số lượng";
            datagrid_mon.Columns[8].HeaderText = "Đơn giá (VNĐ)";
            datagrid_mon.Columns[8].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[9].HeaderText = "Thành tiền (VNĐ)";
            datagrid_mon.Columns[9].DefaultCellStyle.Format = dinhdangso;
           
        }
       // internal void HideShow_ThemBan()
        //{
         //   dg_dsban.DataSource = ban_bul.load_ban();// show lên lưới để đếm số bàn ! nếu lớn hơn 1 thì ẩn controls thêm bàn ngược lại thì hiện lên
           // dg_dsban.Hide();
           // if (dg_dsban.Rows.Count > 1)
           // {
            //    lbthemban.Hide();
              //  Soban.Hide();
              //  bt_themban.Hide();
           // }
           // else
           // {
             //   lbthemban.Show();
              //  Soban.Show();
               // bt_themban.Show();
          //  }
      //  }

        Food_BUL food_bul = new Food_BUL();
        FoodCategory_BUL dmdouong_bul = new FoodCategory_BUL();
     
       
      
        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng đang cập nhật.\n Xin lỗi vì sự bất tiện này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
           // if (datagrid_mon.Rows.Count == 0)
           // {
             //   MessageBox.Show("Chọn một bàn rồi nhấn vào danh sánh món ăn muốn xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
           // else
            //{
             //   BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
             //   billinfo_public.id = MAHOADON_XOA;
             //   billinfo_public.idfood = MADOUONG_XOA;
              //  billinfo_bul.delete_billinfo(billinfo_public);
              //  Load_CTHD(idban);
          //  }

        }
        internal void Load_CTHD(int idban)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.idban = idban;
            bindingSource1.DataSource = billinfo_bul.load_billinfo(billinfo_public);
            datagrid_mon.DataSource = bindingSource1;
            dinhdangluoi();
        }
        private void cbten_Click(object sender, EventArgs e)
        {
            try
            {
                Food_PUBLIC food_public = new Food_PUBLIC();
                food_public.id_dm = int.Parse(cbiddm.Text);
                DataSet dt = new DataSet();
                dt = food_bul.load_douongvoi_where(food_public);
                cbten.DataSource = dt.Tables[0];
                cbten.DisplayMember = "ten_food";
                cbten.ValueMember = "name";
                cbgia.DataSource = dt.Tables[0];
                cbgia.DisplayMember = "dongia";
                cbgia.ValueMember = "Gia";
                cbiddouong.DataSource = dt.Tables[0];
                cbiddouong.DisplayMember = "idfood";
                cbiddouong.ValueMember = "id";
                cbiddm.Hide();
            }
            catch
            {
                MessageBox.Show("Danh mục trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void bt_themban_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng đang cập nhật.\n Xin lỗi vì sự bât tiện này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_chuyenban_Click(object sender, EventArgs e)
        {
            Chuyenban cb = new Chuyenban();
            cb.ShowDialog();
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (idban == 0)
            {
                MessageBox.Show("Chọn một bàn rồi thêm món.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (cbten.Text == "")
            {
                MessageBox.Show("Chưa chọn món.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Bill_PUBLIC bill_public = new Bill_PUBLIC();
                BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
                Ban_PUBLIC ban_public = new Ban_PUBLIC();
                //
                ban_public.IDBAN = idban;
                ban_public.TRANGTHAI = "Có người";
                bill_public.idban = idban;
                bill_public.dateCheckin = DateTime.Now;
                bill_public.dateCheckout = DateTime.Now;
                bill_public.idnv = Idnv;
                bill_public.trangthai = "Chưa";
                bill_bul.insert_bill(bill_public);
                //
                idbill = bill_bul.load_id_with_idban(bill_public);
                billinfo_public.idbill = idbill;
                billinfo_public.idban = idban;
                billinfo_public.idkh = int.Parse(cbidkh.Text);
                billinfo_public.idfood = int.Parse(cbiddouong.Text);
                billinfo_public.soluong = (int)numericsoluongdoan.Value;
                billinfo_bul.insert_billinfo(billinfo_public);
              
                ban_bul.update_trangthaiban(ban_public);
                Load_CTHD(idban);
                datagrid_mon.Show();

            }
        }
        FoodCategory_BUL dm_food_bul = new FoodCategory_BUL();
        private void cbdanhmuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string valueSelected = cbdanhmuc.Text;
            
        }





        public int Idnv
        {
            get
            {
                return idnv;
            }

            set
            {
                idnv = value;
            }
        }
        Khachhang_BUL kh_bul = new Khachhang_BUL();
        private void cbkh_Click(object sender, EventArgs e)
        {
            try
            {
                Khachhang_PUBLIC kh_public = new Khachhang_PUBLIC();
                DataSet dt = new DataSet();
                dt = kh_bul.Loadtenkh(kh_public);
                cbkh.DataSource = dt.Tables[0];
                cbkh.DisplayMember = "ten_kh";
                cbkh.ValueMember = "TenKH";
                cbidkh.DataSource = dt.Tables[0];
                cbidkh.DisplayMember = "idkh";
                cbidkh.ValueMember = "maKH";
                cbidkh.Hide();
            }
            catch
            {
                
            }
        }

        private void Ban_Danhmuc_Load_1(object sender, EventArgs e)
        {
            dg_dsban.Hide();
            this.foodCategoryTableAdapter.Fill(this.cAPHEDataSet.FoodCategory);
            taobanan();
            cbdanhmuc.DropDownStyle = ComboBoxStyle.DropDownList;
            cbten.DropDownStyle = ComboBoxStyle.DropDownList;
            cbgia.DropDownStyle = ComboBoxStyle.DropDownList;
            DataSet dt = new DataSet();
            dt = dmdouong_bul.load_dmdouong();
            cbdanhmuc.DataSource = dt.Tables[0];
            cbdanhmuc.DisplayMember = "tendm";
            cbdanhmuc.ValueMember = "name";
            cbiddm.DataSource = dt.Tables[0];
            cbiddm.DisplayMember = "iddm";
            cbiddm.ValueMember = "id";
            cbiddm.Hide();
            cbiddouong.Hide();
            flowLayoutPanel1.AutoScroll = true;
        }

        private void btn_gopban_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng đang cập nhật.\n Xin lỗi vì sự bất tiện này.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

      
    }
}
