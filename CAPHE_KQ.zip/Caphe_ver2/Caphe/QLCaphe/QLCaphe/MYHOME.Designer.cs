﻿namespace QLCaphe
{
    partial class MYHOME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MYHOME));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.Ban_HoaDon = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Food = new System.Windows.Forms.ToolStripMenuItem();
            this.Nhanvien = new System.Windows.Forms.ToolStripMenuItem();
            this.Khachhang = new System.Windows.Forms.ToolStripMenuItem();
            this.Thongke = new System.Windows.Forms.ToolStripMenuItem();
            this.Dangxuat = new System.Windows.Forms.ToolStripMenuItem();
            this.kho = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 727);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStrip.Size = new System.Drawing.Size(1093, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // Ban_HoaDon
            // 
            this.Ban_HoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Ban_HoaDon.Image = global::QLCaphe.Properties.Resources.BTTOI__27_;
            this.Ban_HoaDon.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.Ban_HoaDon.Name = "Ban_HoaDon";
            this.Ban_HoaDon.Size = new System.Drawing.Size(197, 20);
            this.Ban_HoaDon.Text = "Sơ đồ bàn và thanh toán hóa đơn";
            this.Ban_HoaDon.Click += new System.EventHandler(this.Ban_HoaDon_Click);
            // 
            // Menu_Food
            // 
            this.Menu_Food.Image = global::QLCaphe.Properties.Resources.BTTOI__15_;
            this.Menu_Food.Name = "Menu_Food";
            this.Menu_Food.Size = new System.Drawing.Size(85, 20);
            this.Menu_Food.Text = "Thực đơn";
            this.Menu_Food.Click += new System.EventHandler(this.Menu_Food_Click);
            // 
            // Nhanvien
            // 
            this.Nhanvien.Image = global::QLCaphe.Properties.Resources.BTTOI__24_;
            this.Nhanvien.Name = "Nhanvien";
            this.Nhanvien.Size = new System.Drawing.Size(157, 20);
            this.Nhanvien.Text = "Nhân viên và Tài khoản";
            this.Nhanvien.Click += new System.EventHandler(this.Nhanvien_Click);
            // 
            // Khachhang
            // 
            this.Khachhang.Image = global::QLCaphe.Properties.Resources.BTTOI__23_;
            this.Khachhang.Name = "Khachhang";
            this.Khachhang.Size = new System.Drawing.Size(98, 20);
            this.Khachhang.Text = "Khách hàng";
            this.Khachhang.Click += new System.EventHandler(this.Khachhang_Click);
            // 
            // Thongke
            // 
            this.Thongke.Image = global::QLCaphe.Properties.Resources.BTTOI__7_;
            this.Thongke.Name = "Thongke";
            this.Thongke.Size = new System.Drawing.Size(142, 20);
            this.Thongke.Text = "Thống kê doanh thu";
            this.Thongke.Click += new System.EventHandler(this.Thongke_Click);
            // 
            // Dangxuat
            // 
            this.Dangxuat.Image = global::QLCaphe.Properties.Resources.BTTOI__20_;
            this.Dangxuat.Name = "Dangxuat";
            this.Dangxuat.Size = new System.Drawing.Size(89, 20);
            this.Dangxuat.Text = "Đăng xuất";
            this.Dangxuat.Click += new System.EventHandler(this.Dangxuat_Click);
            // 
            // kho
            // 
            this.kho.Image = global::QLCaphe.Properties.Resources.BTTOI__4_1;
            this.kho.Name = "kho";
            this.kho.Size = new System.Drawing.Size(56, 20);
            this.kho.Text = "Kho";
            this.kho.Click += new System.EventHandler(this.kho_Click_1);
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Ban_HoaDon,
            this.Menu_Food,
            this.Nhanvien,
            this.Khachhang,
            this.Thongke,
            this.kho,
            this.Dangxuat});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1093, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1009, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "***";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MYHOME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::QLCaphe.Properties.Resources._55641994_6144563625624_428850929727438848_n;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1093, 749);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MYHOME";
            this.Text = "V2H Coffee";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MYHOME_FormClosing);
            this.Load += new System.EventHandler(this.MYHOME_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem Ban_HoaDon;
        private System.Windows.Forms.ToolStripMenuItem Menu_Food;
        private System.Windows.Forms.ToolStripMenuItem Nhanvien;
        private System.Windows.Forms.ToolStripMenuItem Khachhang;
        private System.Windows.Forms.ToolStripMenuItem Thongke;
        private System.Windows.Forms.ToolStripMenuItem Dangxuat;
        private System.Windows.Forms.ToolStripMenuItem kho;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.Label label1;
    }
}



