﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Chuyenban : Form
    {
        public Chuyenban()
        {
            InitializeComponent();
        }
        Ban_BUL ban_bul = new Ban_BUL();
        private void Chuyenban_Load(object sender, EventArgs e)
        {
            DataSet dt = new DataSet();
            dt = ban_bul.load_tenbantrong();
            cbbantrong.DataSource = dt.Tables[0];
            cbbantrong.DisplayMember = "tenban";
            cbbantrong.ValueMember = "TEN";
            cbmabantrong.DataSource = dt.Tables[0];
            cbmabantrong.DisplayMember = "idban";
            cbmabantrong.ValueMember = "IDBAN";
            
            DataSet dt1 = new DataSet();
            dt1 = ban_bul.load_tenbanconguoi();
            cbbanconguoi.DataSource = dt1.Tables[0];
            cbbanconguoi.DisplayMember = "tenban";
            cbbanconguoi.ValueMember = "TEN";
            cbmabanconguoi.DataSource = dt1.Tables[0];
            cbmabanconguoi.DisplayMember = "idban";
            cbmabanconguoi.ValueMember = "IDBAN";

            cbmabanconguoi.Hide();
            cbmabantrong.Hide();
        }
        Bill_BUL bill_bul = new Bill_BUL();

        private void btn_chuyen_Click(object sender, EventArgs e)
        {
            if (cbbanconguoi.Text == "")
            {
                MessageBox.Show("Không có bàn nào để chuyển.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Bill_PUBLIC bill_public = new Bill_PUBLIC();
                Ban_PUBLIC ban_public = new Ban_PUBLIC();
                bill_public.idban = int.Parse(cbmabanconguoi.Text);
                int mahoadon_banconguoi = bill_bul.load_id_with_idban(bill_public);
                bill_public.id= mahoadon_banconguoi;
                bill_public.idban = int.Parse(cbmabantrong.Text);// mã bàn mới
                bill_bul.update_bill_doiban(bill_public);
                ban_public.IDBAN = int.Parse(cbmabanconguoi.Text);//update thành Trống
                ban_public.TRANGTHAI = "Trống";
                ban_bul.update_trangthaiban(ban_public);
                ban_public.IDBAN = int.Parse(cbmabantrong.Text);//update thành Có người
                ban_public.TRANGTHAI = "Có người";
                ban_bul.update_trangthaiban(ban_public);
            }
        }

        private void Chuyenban_FormClosing(object sender, FormClosingEventArgs e)
        {

        }


    }
}
