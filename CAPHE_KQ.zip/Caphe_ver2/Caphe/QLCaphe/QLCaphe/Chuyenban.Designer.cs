﻿namespace QLCaphe
{
    partial class Chuyenban
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Chuyenban));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_chuyen = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbmabanconguoi = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbanconguoi = new System.Windows.Forms.ComboBox();
            this.cbmabantrong = new System.Windows.Forms.ComboBox();
            this.cbbantrong = new System.Windows.Forms.ComboBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btn_chuyen);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(338, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(113, 75);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chuyển";
            // 
            // btn_chuyen
            // 
            this.btn_chuyen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_chuyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_chuyen.ForeColor = System.Drawing.Color.Black;
            this.btn_chuyen.Image = global::QLCaphe.Properties.Resources.BTTOI__12_;
            this.btn_chuyen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_chuyen.Location = new System.Drawing.Point(6, 19);
            this.btn_chuyen.Name = "btn_chuyen";
            this.btn_chuyen.Size = new System.Drawing.Size(80, 39);
            this.btn_chuyen.TabIndex = 0;
            this.btn_chuyen.Text = "Chuyển";
            this.btn_chuyen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_chuyen.UseVisualStyleBackColor = true;
            this.btn_chuyen.Click += new System.EventHandler(this.btn_chuyen_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.cbbantrong);
            this.groupBox1.Controls.Add(this.cbmabanconguoi);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbbanconguoi);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(7, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(325, 75);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn bàn cần chuyển";
            // 
            // cbmabanconguoi
            // 
            this.cbmabanconguoi.FormattingEnabled = true;
            this.cbmabanconguoi.Location = new System.Drawing.Point(182, -2);
            this.cbmabanconguoi.Name = "cbmabanconguoi";
            this.cbmabanconguoi.Size = new System.Drawing.Size(61, 26);
            this.cbmabanconguoi.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(136, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sang";
            // 
            // cbbanconguoi
            // 
            this.cbbanconguoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbbanconguoi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbbanconguoi.FormattingEnabled = true;
            this.cbbanconguoi.Location = new System.Drawing.Point(17, 32);
            this.cbbanconguoi.Name = "cbbanconguoi";
            this.cbbanconguoi.Size = new System.Drawing.Size(104, 24);
            this.cbbanconguoi.TabIndex = 3;
            // 
            // cbmabantrong
            // 
            this.cbmabantrong.FormattingEnabled = true;
            this.cbmabantrong.Location = new System.Drawing.Point(256, 10);
            this.cbmabantrong.Name = "cbmabantrong";
            this.cbmabantrong.Size = new System.Drawing.Size(61, 21);
            this.cbmabantrong.TabIndex = 2;
            // 
            // cbbantrong
            // 
            this.cbbantrong.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbbantrong.FormattingEnabled = true;
            this.cbbantrong.Location = new System.Drawing.Point(182, 30);
            this.cbbantrong.Name = "cbbantrong";
            this.cbbantrong.Size = new System.Drawing.Size(121, 26);
            this.cbbantrong.TabIndex = 5;
            // 
            // Chuyenban
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 98);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbmabantrong);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Chuyenban";
            this.Text = "Chuyển bàn";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Chuyenban_FormClosing);
            this.Load += new System.EventHandler(this.Chuyenban_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_chuyen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbmabanconguoi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbanconguoi;
        private System.Windows.Forms.ComboBox cbmabantrong;
        private System.Windows.Forms.ComboBox cbbantrong;
    }
}