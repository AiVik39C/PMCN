﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class MYHOME : Form
    {
        public static MYHOME trangchu;
        private int childFormNumber = 0;

        public MYHOME()
        {
            InitializeComponent();
             trangchu = this;
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

      
        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
         private int IDNV = 0;
        Ban_Danhmuc bandm = new Ban_Danhmuc();
        private void Ban_HoaDon_Click(object sender, EventArgs e)
        {
            bandm.Idnv = IDNV;

             if (!CheckExistForm("Ban_Danhmuc"))
             {
                 Form childForm = new Ban_Danhmuc();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
             }
             else
                 ActiveChildForm("Ban_Danhmuc");
        }

        private void Nhanvien_Click(object sender, EventArgs e)
        {
            if (!CheckExistForm("NhanVien"))
            {
                Form childForm = new NhanVien();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
            }
            else
                ActiveChildForm("NhanVien");
        }

        private void Thongke_Click(object sender, EventArgs e)
        {
            if (!CheckExistForm("Thongkedoanhthu"))
            {
                Form childForm = new Thongkedoanhthu();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
            }
            else
                ActiveChildForm("Thongkedoanhthu");
        }
        // kiểm tra xem 1 Form với tên nào đó đã hiển thị trong Form Cha (frmMain) chưa? => Trả về True (đã hiển thị) hoặc False (nếu chưa hiển thị).
        private bool CheckExistForm(String name)
        {
            bool check = false;
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.Name == name)
                {
                    check = true;
                    break;
                }
            }
            return check;
        }
        // “Kích hoạt”  – hiển thị lên trên cùng các trong số các Form Con nếu nó đã hiện mà không phải tạo thể hiện mới.
        private void ActiveChildForm(string name)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.Name == name)
                {
                    frm.Activate();
                    break;
                }
            }
        }

        private void Dangxuat_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn chắc chắn muốn đăng xuất?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes)
                Application.Exit(); 
        }

        private void Menu_Food_Click(object sender, EventArgs e)
        {
            if (!CheckExistForm("Menu"))
            {
                Form childForm = new Menu();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
            }
            else
                ActiveChildForm("Menu");
        }

       

        private void kho_Click_1(object sender, EventArgs e)
        {
            
            if (!CheckExistForm("OL_Kho"))
            {
                Form childForm = new QL_Kho();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
            }
            else
                ActiveChildForm("QL_Kho");
        
        }

        private void Khachhang_Click(object sender, EventArgs e)
        {
            if (!CheckExistForm("Khachhang"))
            {
                Form childForm = new Khachhang();
                childForm.MdiParent = this;//Đặt form cha cho childForm là form này
                childForm.Show();//Hiển thị nó lên
            }
            else
                ActiveChildForm("Khachhang");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void EnableQuyen(int idnv)
        {
           if (idnv > 0)
            {
               Ban_HoaDon.Enabled = true;
                Menu_Food.Enabled = true;
               Nhanvien.Enabled = true;
               Khachhang.Enabled = true;
              Thongke.Enabled = true;
              kho.Enabled = true;
              Dangxuat.Enabled = true;
                label1.Show();
                label1.Text = "Nhân viên: NV" + idnv;
                IDNV = idnv;
           }
          //  else if (quyen == "NHANVIEN")
           // {
             //   Ban_HoaDon.Enabled = true;
               // Menu_Food.Enabled = true;
              //  Khachhang.Enabled = true;
              //  Thongke.Enabled = true;
              //  kho.Enabled = true;
               // Dangxuat.Enabled = true;
             //   label1.Show();
              //  label1.Text = "Nhân viên: " + ten;
               // IDNV = idnv;
         //   }
        }
        Dangnhap dn = new Dangnhap();
        private void MYHOME_Load(object sender, EventArgs e)
        {
            EnableMNT();
            dn.FormClosing += new FormClosingEventHandler(dn.Dangnhap_FormClosing);
            dn.ShowDialog();
        }

        private void EnableMNT()
        {
            Ban_HoaDon.Enabled = false;
            Menu_Food.Enabled = false;
            Nhanvien.Enabled = false;
            Khachhang.Enabled = false;
            Thongke.Enabled = false;
            kho.Enabled = false;
            Dangxuat.Enabled = false;
            label1.Hide();
        }

        private void MYHOME_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
