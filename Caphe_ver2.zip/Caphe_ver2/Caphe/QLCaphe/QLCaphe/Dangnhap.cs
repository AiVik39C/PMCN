﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Dangnhap_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát chương trình?","Thông báo",MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;

            }
        }
        NhanVien_BUL account_pul = new NhanVien_BUL();
        private void btn_dangnhap_Click(object sender, EventArgs e)
        {
            NhanVien_PUBLIC account_public = new NhanVien_PUBLIC();
            account_public.Username = txt_tendangnhap.Text;
            account_public.Passwrd = txt_matkhau.Text;
            int checkpass = account_pul.check_Account(account_public);
            if (checkpass == 0)
            {
                MessageBox.Show("Sai tên tài khoản hoặc mật khẩu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt_tendangnhap.Focus();
            }
            else if (checkpass == 1)
            {
                MYHOME fr = new MYHOME();
                this.Hide();
                fr.ShowDialog();
                this.Show();
            }
           
        }

        private void Dangnhap_Load(object sender, EventArgs e)
        {

        }
    }
}
