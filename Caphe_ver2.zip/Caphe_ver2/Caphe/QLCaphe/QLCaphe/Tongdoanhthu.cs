﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Tongdoanhthu : Form
    {
        public Tongdoanhthu()
        {
            InitializeComponent();
        }
        private int ngay;
        private int thang;
        private int nam;
        private bool bngay;
        private bool bthang;
        private bool bnam;
        public int Ngay
        {
            get
            {
                return ngay;
            }

            set
            {
                ngay = value;
            }
        }

        public int Thang
        {
            get
            {
                return thang;
            }

            set
            {
                thang = value;
            }
        }

        public int Nam
        {
            get
            {
                return nam;
            }

            set
            {
                nam = value;
            }
        }

        public bool Bngay
        {
            get
            {
                return bngay;
            }

            set
            {
                bngay = value;
            }
        }

        public bool Bthang
        {
            get
            {
                return bthang;
            }

            set
            {
                bthang = value;
            }
        }

        public bool Bnam
        {
            get
            {
                return bnam;
            }

            set
            {
                bnam = value;
            }
        }
        private bool timcheck;
        private bool checkten;
        private string tenban;
        public bool Timcheck
        {
            get
            {
                return timcheck;
            }

            set
            {
                timcheck = value;
            }
        }

        public string Tenban
        {
            get
            {
                return tenban;
            }

            set
            {
                tenban = value;
            }
        }

        public bool Checkten
        {
            get
            {
                return checkten;
            }

            set
            {
                checkten = value;
            }
        }

        Bill_OLD_BUL hd_old_bul = new Bill_OLD_BUL();
        private void load_dshd_ngay()
        {
            Bill_OLD_PUBLIC hd_old_public = new Bill_OLD_PUBLIC();
            hd_old_public.Ngay = Ngay;
            dg_dshd.DataSource = hd_old_bul.load_bill_day(hd_old_public);
        }
        private void load_dshd_thang()
        {
            Bill_OLD_PUBLIC hd_old_public = new Bill_OLD_PUBLIC();
            hd_old_public.Thang = Thang;
            dg_dshd.DataSource = hd_old_bul.load_bill_month(hd_old_public);
        }
        private void load_dshd_nam()
        {
            Bill_OLD_PUBLIC hd_old_public = new Bill_OLD_PUBLIC();
            hd_old_public.Nam = Nam;
            dg_dshd.DataSource = hd_old_bul.load_bill_year(hd_old_public);
        }
        private void dinhdangluoi()
        {
            dg_dshd.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            dg_dshd.Columns[0].HeaderText = "Mã hóa đơn";
            dg_dshd.Columns[1].HeaderText = "Tên";
            dg_dshd.Columns[2].HeaderText = "Tên nhân viên";
            dg_dshd.Columns[3].HeaderText = "Ngày lập hóa đơn";
            dg_dshd.Columns[4].HeaderText = "Thanh toán";
            dg_dshd.Columns[5].HeaderText = "Tổng tiền";
            dg_dshd.Columns[5].DefaultCellStyle.Format = dinhdangso;
        }

        private void tinhtongtien(int vitri)
        {
            double tongtien = 0;
            for (int i = 0; i < dg_dshd.Rows.Count - 1; ++i)
            {
                tongtien += Convert.ToDouble(dg_dshd.Rows[i].Cells[vitri].Value.ToString());
            }
            txttongtien.Text = tongtien.ToString("###,###,##0");
        }
        string trangthai = "";

        private void dinhdangluoi_hd_ban()
        {
            string dinhdangso = "###,###,##0";
            dg_dshd.ReadOnly = true;
            dg_dshd.Columns[0].HeaderText = "Mã hóa đơn";
            dg_dshd.Columns[1].HeaderText = "Tên bàn";
            dg_dshd.Columns[2].HeaderText = "Tên nhân viên";
            dg_dshd.Columns[3].HeaderText = "Ngày lập hóa đơn";
            dg_dshd.Columns[4].HeaderText = "Thanh toán";
            dg_dshd.Columns[5].HeaderText = "Tổng tiền(VNĐ)";
            dg_dshd.Columns[5].DefaultCellStyle.Format = dinhdangso;
        }

        private void TONGDOANHTHU_Load(object sender, EventArgs e)
        {
            txttongtien.ReadOnly = true;
            groupBox2.Text = "Tổng doanh thu(VNĐ)";
            if (Bngay == true)
            {
                trangthai = "Ngày";
                load_dshd_ngay();
                dinhdangluoi();
                groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn theo Ngày: " + Ngay.ToString();
                tinhtongtien(5);
            }
            else if (Bthang == true)
            {
                trangthai = "Tháng";
                load_dshd_thang();
                dinhdangluoi();
                groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn theo Tháng: " + Thang.ToString();
                tinhtongtien(5);
            }
            else if (Bnam == true)
            {
                trangthai = "Năm";
                load_dshd_nam();
                dinhdangluoi();
                groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn theo Năm: " + Nam.ToString();
                tinhtongtien(5);
            }
            else if (Timcheck == true)
            {
                trangthai = Tenban;
                Bill_OLD_PUBLIC hd_old_public = new Bill_OLD_PUBLIC();
                hd_old_public.soban = Tenban;
                dg_dshd.DataSource = hd_old_bul.load_timbill_old(hd_old_public);
                dinhdangluoi_hd_ban();
                groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn theo " + Tenban;
                tinhtongtien(5);
            }
            else if (Checkten == true)
            {
                trangthai = Tenban;
                Bill_OLD_PUBLIC hd_old_public = new Bill_OLD_PUBLIC();
                hd_old_public.TenNV = Tenban;
                dg_dshd.DataSource = hd_old_bul.load_timbill_old_TENNV(hd_old_public);
                dinhdangluoi_hd_ban();
                groupBoxTONGDOANHTHU.Text = "Danh sách hóa đơn của nhân viên: " + Tenban;
                tinhtongtien(5);
            }
            else
            {
                trangthai = "Tất cả các hóa đơn";
                dg_dshd.DataSource = hd_old_bul.load_bill_old_NOTID();
                dinhdangluoi();
                groupBoxTONGDOANHTHU.Text = "Danh sách tất cả các hóa đơn";
                tinhtongtien(5);
            }
        }
        
        private void Tongdoanhthu_Load(object sender, EventArgs e)
        {

        }

        internal void Tongdoanhthu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Thongkedoanhthu.tkdt.btlammoi_Click(sender, e);
        }
    }
}
