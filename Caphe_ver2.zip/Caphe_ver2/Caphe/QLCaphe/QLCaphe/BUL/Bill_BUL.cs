﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class Bill_BUL
    {
        Bill_DAL bill_dal = new Bill_DAL();
        public DataTable load_bill()
        {
            return bill_dal.load_bill();
        }
        public int insert_bill(Bill_PUBLIC bill_public)
        {
            return bill_dal.insert_bill(bill_public);
        }
        public int update_bill(Bill_PUBLIC bill_public)
        {
            return bill_dal.update_bill(bill_public);
        }
        public int delete_bill(Bill_PUBLIC bill_public)
        {
            return bill_dal.delete_bill(bill_public);
        }
        public int count_bill_ban(Bill_PUBLIC bill_public)
        {
            return bill_dal.count_bill_ban(bill_public);
        }
        public int delete_bill_with_idban(Bill_PUBLIC bill_public)
        {
            return bill_dal.delete_bill_with_idban(bill_public);
        }
        public int load_idban_with_id(Bill_PUBLIC bill_public)
        {
            return bill_dal.load_idban_with_id(bill_public);
        }
        public int update_bill_doiban(Bill_PUBLIC bill_public)
        {
            return bill_dal.update_bill_doiban(bill_public);
        }



        public int load_id_with_idban(Bill_PUBLIC bill_public)
        {
            return bill_dal.load_id_with_idban(bill_public);
        }
    }
}
