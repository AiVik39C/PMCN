﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class BillInfo_OLD_BUL
    {

        BillInfo_OLD_DAL billinfo_old_dal = new BillInfo_OLD_DAL();
        public DataTable load_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            return billinfo_old_dal.load_billinfo_old(billinfo_old);
        }
        public DataTable load_billinfo_old_printer(BillInfo_OLD_PUBLIC billinfo_old)
        {
            return billinfo_old_dal.load_billinfo_old_printer(billinfo_old);
        }
        public int insert_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            return billinfo_old_dal.insert_billinfo_old(billinfo_old);
        }
        public int delete_billinfo_old(BillInfo_OLD_PUBLIC billinfo_old)
        {
            return billinfo_old_dal.delete_billinfo_old(billinfo_old);
        }
    }
}
