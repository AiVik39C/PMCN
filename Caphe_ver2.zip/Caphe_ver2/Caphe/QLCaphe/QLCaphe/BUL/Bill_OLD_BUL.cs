﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class Bill_OLD_BUL
    {
        Bill_OLD_DAL bill_dal_old = new Bill_OLD_DAL();
        public DataTable load_bill_old()
        {
            return bill_dal_old.load_bill_old();
        }
        public int insert_bill_old(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.insert_bill_old(bill_old);
        }
        public int delete_bill_old(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.delete_bill_old(bill_old);
        }
        public DataTable load_timbill_old(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.load_timbill_old(bill_old);
        }
        public DataTable load_bill_day(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.load_bill_day(bill_old);
        }
        public DataTable load_bill_month(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.load_bill_month(bill_old);
        }
        public DataTable load_bill_year(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.load_bill_year(bill_old);
        }
        public DataTable load_bill_old_NOTID()
        {
            return bill_dal_old.load_bill_old_NOTID();
        }
        public DataTable load_timbill_old_TENNV(Bill_OLD_PUBLIC bill_old)
        {
            return bill_dal_old.load_timbill_old_TENNV(bill_old);
        }
    }
}
