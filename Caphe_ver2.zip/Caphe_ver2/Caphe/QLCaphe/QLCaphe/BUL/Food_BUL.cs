﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class Food_BUL
    {
        Food_DAL food_dal = new Food_DAL();
        public DataTable load_food()
        {
            return food_dal.load_food();
        }
        public int insert_food(Food_PUBLIC food_public)
        {
            return food_dal.insert_food(food_public);
        }
        public int update_food(Food_PUBLIC food_public)
        {
            return food_dal.update_food(food_public);
        }
        public int delete_food(Food_PUBLIC food_public)
        {
            return food_dal.delete_food(food_public);
        }
        public DataTable foodfind(int id_dm)
        {
            return food_dal.foodfind(id_dm);
        }
        public DataTable TIM_Food(Food_PUBLIC food_public)
        {
            return food_dal.TIM_Food(food_public);
        }
        public DataTable load_in_dsfood()
        {
            return food_dal.load_in_dsfood();
        }
        public DataTable load_douongvoi_where(Food_PUBLIC food_public)
        {
            return food_dal.load_douongvoi_where(food_public);
        }

    }
}
