﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class Ban_BUL
    {
        Ban_DAL ban_dal = new Ban_DAL();
        public DataTable load_ban()
        {
            return ban_dal.load_ban();
        }
        public int insert_ban(Ban_PUBLIC ban_public)
        {
            return ban_dal.insert_ban(ban_public);
        }
        public int update_ban(Ban_PUBLIC ban_public)
        {
            return ban_dal.update_ban(ban_public);
        }
        public int delete_ban(Ban_PUBLIC ban_public)
        {
            return ban_dal.delete_ban(ban_public);
        }
        public List<Ban_PUBLIC> Loaddsban()
        {
            return ban_dal.Loaddsban();
        }
        public int update_trangthaiban(Ban_PUBLIC ban_public)
        {
            return ban_dal.update_trangthaiban(ban_public);
        }
        public DataTable load_ban_trong()
        {
            return ban_dal.load_ban_trong();
        }
        public DataTable load_ban_conguoi()
        {
            return ban_dal.load_ban_conguoi();
        }
    }
}
