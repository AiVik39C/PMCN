﻿using QLCaphe.DAL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.BUL
{
    public class NhanVien_BUL
    {
        NhanVien_DAL nhanvien_dal = new NhanVien_DAL();
        public DataTable load_nhanvien()
        {
            return nhanvien_dal.load_nhanvien();
        }
        public int insert_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            return nhanvien_dal.insert_nhanvien(nhanvien_public);
        }
        public int update_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            return nhanvien_dal.update_nhanvien(nhanvien_public);
        }
        public int delete_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            return nhanvien_dal.delete_nhanvien(nhanvien_public);
        }

        public int count_nhanvien()
        {
            return nhanvien_dal.count_nhanvien();
        }
        public DataTable Tim_nv(NhanVien_PUBLIC nhanvien_public)
        {
            return nhanvien_dal.Tim_nv(nhanvien_public);
        }

        public int check_Account(NhanVien_PUBLIC account_public)
        {
            return nhanvien_dal.check_Account(account_public);
        }


    }
}
