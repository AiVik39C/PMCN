﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class QL_Kho : Form
    {
        public QL_Kho()
        {
            InitializeComponent();
        }

        private void xulybuttion(bool b)
        {
            btn_them.Enabled = datagrid_kho.Enabled = btn_TimKiem.Enabled = txt_TimKiem.Enabled = btn_sua.Enabled = btn_xoa.Enabled = btn_Thoat.Enabled = b;
            btn_luu.Enabled = btn_Huy.Enabled = !b;
        }
        private bool nutThem = false, nutSua = false;

        Kho_BUL mathang_bul = new Kho_BUL();
        private void LoadDataGrid()
        {
            bindingSource1.DataSource = mathang_bul.getAllMatHang();
            datagrid_kho.DataSource = bindingSource1;
        }
        private void EditDataGrid()
        {
            datagrid_kho.ReadOnly = true;
            datagrid_kho.Columns[0].HeaderText = "Mã hàng";
            datagrid_kho.Columns[1].HeaderText = "Tên hàng";
            datagrid_kho.Columns[2].HeaderText = "Giá";
            datagrid_kho.Columns[3].HeaderText = "Đơn vị tính";
            datagrid_kho.Columns[4].HeaderText = "Ngày nhập";
            
        }
      
        private void Clear()
        {
            txt_mahang.Clear();
            txt_tenhang.Clear();
            txt_Gia.Clear();
            cb_DVT.SelectedIndex = -1;
            date_ngaynhap.ResetText();
            

        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        
        private void btn_TimKiem_Click(object sender, EventArgs e)
        {
            if (txt_TimKiem.TextLength == 0)
            {
                MessageBox.Show("Chưa nhập tên mặt hàng cần tìm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Kho_PUBLIC kho_public = new Kho_PUBLIC();
                kho_public.Timten = txt_TimKiem.Text;
                datagrid_kho.DataSource = mathang_bul.FindMatHang(kho_public);
                datagrid_kho.Rows[0].Selected = true;
            }
        }

     
        private void QL_Kho_Load(object sender, EventArgs e)
        {
            xulybuttion(true);
            LoadDataGrid();
            EditDataGrid();
          
        }
       

        private void btn_them_Click(object sender, EventArgs e)
        {
            nutThem = true;
            xulybuttion(false);
            txt_mahang.Focus();
            Clear();
        }
        Kho_BUL kho_bul = new Kho_BUL();
        private void btn_xoa_Click(object sender, EventArgs e)
        {

            if (DialogResult.Yes == MessageBox.Show("Muốn xóa một mặt hàng?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {


                DeleteMatHang();
                LoadDataGrid();
            }
        }
        private void DeleteMatHang()
        {
            Kho_PUBLIC kho_public = new Kho_PUBLIC();
            kho_public.mamh = txt_mahang.Text;
            mathang_bul.DeleteMatHang(kho_public);
        }

         private void InsertMatHang()
        {
            Kho_PUBLIC kho_public = new Kho_PUBLIC();
            kho_public.mamh = txt_mahang.Text;
            kho_public.Tenhang = txt_tenhang.Text;
            kho_public.Gia = Decimal.Parse(txt_Gia.Text);
            kho_public.DVT = cb_DVT.Text;
            kho_public.Ngaynhap = DateTime.Parse(date_ngaynhap.Text);
            kho_bul.InsertMatHang(kho_public);
        }

         private void UpdateMatHang()
         {
             Kho_PUBLIC kho_public = new Kho_PUBLIC();
             kho_public.mamh = txt_mahang.Text;
             kho_public.Tenhang = txt_tenhang.Text;
             kho_public.Gia = Decimal.Parse(txt_Gia.Text);
             kho_public.DVT = cb_DVT.Text;
             kho_public.Ngaynhap = DateTime.Parse(date_ngaynhap.Text);
             kho_bul.UpdateMathang(kho_public);
         }
        private void btn_Huy_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                //
                LoadDataGrid();
                xulybuttion(true);
                nutThem = false;
            }
            else if (nutSua == true)
            {
                //
                xulybuttion(true);
                nutSua = false;
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            nutSua = true;
            xulybuttion(false);
        }

        private void btn_luu_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                if (txt_mahang.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền mã mặt hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (txt_tenhang.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên mặt hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (cb_DVT.Text == "")
                {
                    MessageBox.Show("Chưa chọn đơn vị tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_Gia.TextLength < 3)
                {
                    MessageBox.Show("Chưa điền giá tiền.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {
                    try
                    {
                        nutThem = false;
                        InsertMatHang();
                        LoadDataGrid();
                        xulybuttion(true);
                    }
                    catch
                    {
                    }
                }
            }
            else if (nutSua == true)
            {
                if (txt_mahang.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền mã mặt hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (txt_tenhang.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên mặt hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (cb_DVT.Text == "")
                {
                    MessageBox.Show("Chưa chọn đơn vị tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_Gia.TextLength < 3)
                {
                    MessageBox.Show("Chưa điền giá tiền.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {

                    UpdateMatHang();
                    xulybuttion(true);
                    nutSua = false;
                    LoadDataGrid();
                }
            }
        }

        private void datagrid_kho_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int dong = e.RowIndex;
            txt_mahang.Text = datagrid_kho.Rows[dong].Cells[0].Value.ToString();
            txt_tenhang.Text = datagrid_kho.Rows[dong].Cells[1].Value.ToString();
            txt_Gia.Text = datagrid_kho.Rows[dong].Cells[2].Value.ToString();
            cb_DVT.Text = datagrid_kho.Rows[dong].Cells[3].Value.ToString();
            date_ngaynhap.Text = datagrid_kho.Rows[dong].Cells[4].Value.ToString();

        }
            int index;
            private void datagrid_kho_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {
                index = datagrid_kho.CurrentRow.Index;
                txt_mahang.Text = datagrid_kho.Rows[index].Cells[0].Value.ToString();
                txt_tenhang.Text = datagrid_kho.Rows[index].Cells[1].Value.ToString();
                txt_Gia.Text = datagrid_kho.Rows[index].Cells[2].Value.ToString();
                cb_DVT.Text = datagrid_kho.Rows[index].Cells[3].Value.ToString();
                date_ngaynhap.Text = datagrid_kho.Rows[index].Cells[4].Value.ToString();
                
            }

            private void datagrid_kho_CellClick(object sender, DataGridViewCellEventArgs e)
            {
                index = datagrid_kho.CurrentRow.Index;
                txt_mahang.Text = datagrid_kho.Rows[index].Cells[0].Value.ToString();
                txt_tenhang.Text = datagrid_kho.Rows[index].Cells[1].Value.ToString();
                txt_Gia.Text = datagrid_kho.Rows[index].Cells[2].Value.ToString();
                cb_DVT.Text = datagrid_kho.Rows[index].Cells[3].Value.ToString();
                date_ngaynhap.Text = datagrid_kho.Rows[index].Cells[4].Value.ToString();
                
            }

        }

    }

