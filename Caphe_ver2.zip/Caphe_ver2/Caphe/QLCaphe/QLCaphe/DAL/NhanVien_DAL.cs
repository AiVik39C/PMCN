﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class NhanVien_DAL
    {
        KNDL ketnoi = new KNDL();

        public int check_Account(NhanVien_PUBLIC taikhoan_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@Username";
            name[1] = "@Passwrd";
            values[0] = taikhoan_public.Username;
            values[1] = taikhoan_public.Passwrd;
            string sql = "SELECT COUNT(*) FROM NHANVIEN WHERE NHANVIEN.Username=@Username AND NHANVIEN.Passwd=@Passwrd";
            return ketnoi.ReturnValueIntWithParameter(sql, name, values, parameter);
        }
        public DataTable load_nhanvien()
        {
            string sql = "SELECT * From NHANVIEN";
            return ketnoi.Load_Data(sql);
        }
        public int insert_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            int parameter = 8;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@manv";
            name[1] = "@TenNV";
            name[2] = "@Ngaysinh";
            name[3] = "@Sodienthoai";
            name[4] = "@Gioitinh";
            name[5] = "@Username";
            name[6] = "@Passwrd";
            name[7] = "@Quyen";
            values[0] = nhanvien_public.manv;
            values[1] = nhanvien_public.TenNV;
            values[2] = nhanvien_public.Ngaysinh;
            values[3] = nhanvien_public.Sodienthoai;
            values[4] = nhanvien_public.Gioitinh;
            values[5] = nhanvien_public.Username;
            values[6] = nhanvien_public.Passwrd;
            values[7] = nhanvien_public.Quyen;
            string sql = "INSERT INTO NHANVIEN(TenNV,Ngaysinh,Sodienthoai,Gioitinh,Username,Passwd,Quyen) VALUES(@TenNV,@Ngaysinh,@Sodienthoai,@Gioitinh,@Username,@Passwrd,@Quyen)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            int parameter = 8;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@manv";
            name[1] = "@TenNV";
            name[2] = "@Ngaysinh";
            name[3] = "@Sodienthoai";
            name[4] = "@Gioitinh";
            name[5] = "@Username";
            name[6] = "@Passwrd";
            name[7] = "@Quyen";

            values[0] = nhanvien_public.manv;
            values[1] = nhanvien_public.TenNV;
            values[2] = nhanvien_public.Ngaysinh;
            values[3] = nhanvien_public.Sodienthoai;
            values[4] = nhanvien_public.Gioitinh;
            values[5] = nhanvien_public.Username;
            values[6] = nhanvien_public.Passwrd;
            values[7] = nhanvien_public.Quyen;
            string sql = "UPDATE NHANVIEN SET TenNV=@TenNV,Ngaysinh =@Ngaysinh ,Sodienthoai=@Sodienthoai,Gioitinh=@Gioitinh,Username=@Username ,Passwd=@Passwrd,Quyen=@Quyen where manv=@manv";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_nhanvien(NhanVien_PUBLIC nhanvien_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@manv";
            values[0] = nhanvien_public.manv;
            string sql = "DELETE FROM NHANVIEN WHERE manv=@manv";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int count_nhanvien()
        {
            string sql = "SELECT COUNT(*)+ABS(CHECKSUM(NewId())) % 1000 FROM NHANVIEN";
            return ketnoi.ReturnValueInt(sql);
        }
        public DataTable Tim_nv(NhanVien_PUBLIC nhanvien_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@TenNV";
            values[0] = nhanvien_public.TIMTEN;
            string sql = "SELECT NHANVIEN.manv,NHANVIEN.TenNV,NHANVIEN.Ngaysinh,NHANVIEN.Sodienthoai,NHANVIEN.Gioitinh,NHANVIEN.Username,NHANVIEN.Passwd,NHANVIEN.Quyen FROM NHANVIEN  where NHANVIEN.TenNV like '%'+@TenNV+'%'";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
    }
}
