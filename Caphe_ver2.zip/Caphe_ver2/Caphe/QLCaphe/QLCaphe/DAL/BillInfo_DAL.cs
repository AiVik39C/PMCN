﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class BillInfo_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable load_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idban";
            values[0] = billinfo_public.idban;
            string sql = "SELECT BillInfo.id,BillInfo.idbill,BAN.TEN,NHANVIEN.TenNV,KHACHHANG.TenKH,FoodCategory.name,Food.name,BillInfo.soluong,Food.Gia,(BillInfo.soluong*Food.Gia) FROM BillInfo inner join Food on BillInfo.idfood=Food.id inner join BAN on BillInfo.idban=BAN.IDBAN inner join NHANVIEN on BillInfo.idnv= NHANVIEN.manv inner join KHACHHANG on BillInfo.idkh= KHACHHANG.maKH inner join FoodCategory on Food.idCategory=FoodCategory.id WHERE BillInfo.idbill=@idban";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable load_billinfo_thanhtoan(BillInfo_PUBLIC billinfo_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill";
            values[0] = billinfo_public.idbill;
            string sql = "SELECT Food.id,Food.name,BillInfo.soluong,Food.Gia,(BillInfo.soluong*Food.Gia),FoodCategory.name FROM BillInfo inner join Food on BillInfo.idfood=Food.id inner join FoodCategory on Food.idCategory=FoodCategory.id WHERE BillInfo.idbill=@idbill";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public int insert_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            int parameter = 6;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill";
            name[1] = "@idban";
            name[2] = "@idfood";
            name[3] = "@manv";
            name[4] = "@idkh";
            name[5] = "@soluong";
            values[0] = billinfo_public.idbill;
            values[1] = billinfo_public.idban;
            values[2] = billinfo_public.idfood;
            values[3] = billinfo_public.manv;
            values[4] = billinfo_public.idkh;
            values[5] = billinfo_public.soluong;
            string sql = "INSERT INTO BillInfo(idbill,idban,idfood,idnv,idkh,soluong) VALUES(@idbill,@idban,@idfood,@idnv,@idkh,@soluong)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            int parameter = 7;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id";
            name[1] = "@idbill";
            name[2] = "@idban";
            name[3] = "@idfood";
            name[4] = "@manv";
            name[5] = "@idkh";
            name[6] = "@soluong";
            values[0] = billinfo_public.id;
            values[1] = billinfo_public.idbill;
            values[2] = billinfo_public.idban;
            values[3] = billinfo_public.idfood;
            values[4] = billinfo_public.manv;
            values[5] = billinfo_public.idkh;
            values[6] = billinfo_public.soluong;
            string sql = "UPDATE BillInfo SET idbill=@idbill,idban=@idban ,idfood=@idfood,manv=@manv,idkh=@idkh,soluong=@soluong where id=@id";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_billinfo(BillInfo_PUBLIC billinfo_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill";
            name[1] = "@idfood";
            values[0] = billinfo_public.idbill;
            values[1] = billinfo_public.idfood;
            string sql = "DELETE FROM BillInfo WHERE idbill=@idbill AND idfood=@idfood";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
    }
}
