﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class Ban_DAL
    {
         KNDL ketnoi = new KNDL();
        public DataTable load_ban()
        {
            string sql = "SELECT * FROM BAN ORDER BY ODER ASC";
            return ketnoi.Load_Data(sql);
        }
        public DataTable load_ban_trong()
        {
            string sql = "SELECT * FROM BAN WHERE BAN.TRANGTHAI=N'Trống'";
            return ketnoi.Load_Data(sql);
        }
        public DataTable load_ban_conguoi()
        {
            string sql = "SELECT * FROM BAN WHERE BAN.TRANGTHAI=N'Có người'";
            return ketnoi.Load_Data(sql);
        }
        public int insert_ban(Ban_PUBLIC ban_public)
        {
            int parameter = 3;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@TEN";
            name[1] = "@TRANGTHAI";
            name[2] = "@ODER";
            values[0] = ban_public.TEN;
            values[1] = ban_public.TRANGTHAI;
            values[2] = ban_public.ODER;
            string sql = "INSERT INTO BAN(TEN,TRANGTHAI,ODER) VALUES(@TEN,@TRANGTHAI,@ODER)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_ban(Ban_PUBLIC ban_public)
        {
            int parameter = 3;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@IDBAN";
            name[1] = "@TEN";
            name[2] = "@TRANGTHAI";
            values[0] = ban_public.IDBAN;
            values[1] = ban_public.TEN;
            values[2] = ban_public.TRANGTHAI;
            string sql = "UPDATE_BAN";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_ban(Ban_PUBLIC ban_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@IDBAN";
            values[0] = ban_public.IDBAN;
            string sql = "DELETE FROM BAN WHERE IDBAN=@IDBAN";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public List<Ban_PUBLIC> Loaddsban()
        {
            List<Ban_PUBLIC> dsban = new List<Ban_PUBLIC>();
            DataTable dt = new DataTable();
            dt = load_ban();
            foreach (DataRow dong in dt.Rows)
            {
                Ban_PUBLIC table = new Ban_PUBLIC(dong);
                dsban.Add(table);
            }
            return dsban;
        }
        public int update_trangthaiban(Ban_PUBLIC ban_public)
        {
            int parameter = 2;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@IDBAN";
            name[1] = "@TRANGTHAI";
            values[0] = ban_public.IDBAN;
            values[1] = ban_public.TRANGTHAI;
            string sql = "UPDATE BAN SET TRANGTHAI=@TRANGTHAI WHERE IDBAN=@IDBAN";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
    }
    }

