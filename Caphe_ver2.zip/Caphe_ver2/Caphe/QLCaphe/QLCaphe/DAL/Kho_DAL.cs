﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class Kho_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable getAllMatHang()
        {
            string sql = "SELECT * FROM Kho";
            return ketnoi.Load_Data(sql);
        }

        public int InsertMatHang(Kho_PUBLIC  kho_public )
        {
            int parameter = 5;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@mamh";
            name[1] = "@Tenhang";
            name[2] = "@Gia";
            name[3] = "@DVT";
            name[4] = "@Ngaynhap";

            values[0] = kho_public.mamh;
            values[1] = kho_public.Tenhang;
            values[2] = kho_public.Gia;
            values[3] = kho_public.DVT;
            values[4] = kho_public.Ngaynhap;
            string sql = "INSERT INTO Kho(mamh, Tenhang, Gia, DVT, Ngaynhap) values (@mamh, @Tenhang, @Gia, @DVT, @Ngaynhap)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
           
        }

        public int UpdateMathang(Kho_PUBLIC kho_public)
        {
            int parameter = 5;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@mamh";
            name[1] = "@Tenhang";
            name[2] = "@Gia";
            name[3] = "@DVT";
            name[4] = "@Ngaynhap";

            values[0] = kho_public.mamh;
            values[1] = kho_public.Tenhang;
            values[2] = kho_public.Gia;
            values[3] = kho_public.DVT;
            values[4] = kho_public.Ngaynhap;
            string sql = "update Kho set Tenhang = @Tenhang, Gia= @Gia, DVT = @DVT, Ngaynhap = @Ngaynhap) values (@Tenhang, @Gia, @DVT, @Ngaynhap where mamh = @mamh)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
            
        }

        public int DeleteMatHang(Kho_PUBLIC kho_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@mamh";
            values[0] = kho_public.mamh;
            string sql = "DELETE FROM Kho WHERE mamh=@mamh";
            return ketnoi.Excute_Data(sql, name, values, parameter);
           
        }

        public DataTable FindMatHang(Kho_PUBLIC kho_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@Tenhang";
            values[0] = kho_public.Timten;
            string sql = "SELECT * FROM Kho where Tenhang like '%'+@Tenhang+'%'";
            return ketnoi.Load_Data(sql);

   
        }
    }
}
