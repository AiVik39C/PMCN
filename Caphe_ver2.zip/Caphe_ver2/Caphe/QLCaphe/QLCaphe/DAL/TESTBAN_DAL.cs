﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class TESTBAN_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable loadban()
        {
            string sql = "SELECT * FROM BAN ORDER BY ODER ASC";
            return ketnoi.Load_Data(sql);
        }
        // tao ham load ban an 
        public List<TESTBAN_PUBLIC> load_ds_ban()
        {
            List<TESTBAN_PUBLIC> dsban = new List<TESTBAN_PUBLIC>();
            DataTable dt = new DataTable();
            dt = loadban();
            foreach (DataRow dong in dt.Rows)
            {
                TESTBAN_PUBLIC taoban = new TESTBAN_PUBLIC(dong);
                dsban.Add(taoban);
            }
            return dsban;
        }
    }
}
