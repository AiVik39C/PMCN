﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class Bill_OLD_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable load_bill_old()
        {
            string sql = "SELECT Bill_OLD.id_OLD,Bill_OLD.idbill,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLD INNER JOIN BAN ON Bill_OLD.idban=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv";
            return ketnoi.Load_Data(sql);
        }
        public DataTable load_bill_old_NOTID()
        {
            string sql = "SELECT Bill_OLD.id_OLD,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLD INNER JOIN BAN ON Bill_OLD.idban=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv";
            return ketnoi.Load_Data(sql);
        }
        public int insert_bill_old(Bill_OLD_PUBLIC bill_old)
        {
            int parameter = 6;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idbill";
            name[1] = "@idban";
            name[2] = "@manv";
            name[3] = "@Ngaylap";
            name[4] = "@Trangthai";
            name[5] = "@Tongtien";
            values[0] = bill_old.idbill;
            values[1] = bill_old.idban;
            values[2] = bill_old.manv;
            values[3] = bill_old.Ngaylap;
            values[4] = bill_old.Trangthai;
            values[5] = bill_old.Tongtien;
            string sql = "INSERT INTO Bill_OLD(idbill,idban,manv,Ngaylap,Trangthai,Tongtien) VALUES(@idbill,@idban,@manv,@Ngaylap,@Trangthai,@Tongtien)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_bill_old(Bill_OLD_PUBLIC bill_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id_OLD";
            values[0] = bill_old.id_OLD;
            string sql = "DELETE FROM Bill_OLD WHERE id_OLD=@id_OLD";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public DataTable load_timbill_old(Bill_OLD_PUBLIC bill_old)
        {
            int paramater = 1;
            string[] name = new string[paramater];
            object[] values = new object[paramater];
            name[0] = "@soban";
            values[0] = bill_old.soban;
            string sql = "SELECT Bill_OLD.idbill,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLD INNER JOIN BAN ON Bill_OLD.idban=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv WHERE BAN.TEN =@soban ";
            return ketnoi.LoadDataWithParameter(sql, name, values, paramater);
        }
        public DataTable load_timbill_old_TENNV(Bill_OLD_PUBLIC bill_old)
        {
            int paramater = 1;
            string[] name = new string[paramater];
            object[] values = new object[paramater];
            name[0] = "@TenNV";
            values[0] = bill_old.TenNV;
            string sql = "SELECT Bill_OLD.idban,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLD INNER JOIN BAN ON Bill_OLD.idban=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv WHERE NHANVIEN.TenNV =@TenNV ";
            return ketnoi.LoadDataWithParameter(sql, name, values, paramater);
        }
        public DataTable load_bill_day(Bill_OLD_PUBLIC bill_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@Ngay";
            values[0] = bill_old.Ngay;
            string sql = "SELECT Bill_OLD.idbill,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLD INNER JOIN BAN ON Bill_OLD.idban=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv WHERE DAY(Bill_OLD.Ngaylap)=@Ngay";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable load_bill_month(Bill_OLD_PUBLIC bill_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@Thang";
            values[0] = bill_old.Thang;
            string sql = "SELECT Bill_OLD.idbill,BAN.TEN,NHANVIEN.TenNV,Bill_OLD.Ngaylap,Bill_OLD.Trangthai,Bill_OLD.Tongtien FROM Bill_OLDINNER JOIN BAN ON Bill_OLD.IDBAN=BAN.IDBAN INNER JOIN NHANVIEN ON Bill_OLD.manv=NHANVIEN.manv WHERE MONTH(Bill_OLD.Ngaylap)=@Thang";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable load_bill_year(Bill_OLD_PUBLIC bill_old)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@Nam";
            values[0] = bill_old.Nam;
            string sql = "LOAD_HD_YEAR";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
    }
}
