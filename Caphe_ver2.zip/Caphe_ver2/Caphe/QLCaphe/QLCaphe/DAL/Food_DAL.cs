﻿using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.DAL
{
    public class Food_DAL
    {
        KNDL ketnoi = new KNDL();
        public DataTable load_food()
        {
            string sql = "SELECT Food.id,Food.name,FoodCategory.name,FoodCategory.id,Food.Gia FROM Food inner join FoodCategory on FoodCategory.id=Food.idCategory";
            return ketnoi.Load_Data(sql);
        }
        public DataTable load_in_dsfood()
        {
            string sql = "SELECT Food.name,Food.Gia FROM Food";
            return ketnoi.Load_Data(sql);
        }
        public DataTable load_douongvoi_where(Food_PUBLIC food_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id_dm";
            values[0] = food_public.id_dm;
            string sql = "SELECT * FROM Food WHERE food.idCategory=@id_dm";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable foodfind(int id_dm)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id_dm";
            values[0] = id_dm;
            string sql = "SELECT name,Gia FROM Food WHERE idCategory=@id_dm";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public DataTable TIM_Food(Food_PUBLIC food_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@ten_food";
            values[0] = food_public.ten_food;
            string sql = "SELECT Food.id,FoodCategory.name,Food.name,Food.Gia FROM Food INNER JOIN FoodCategory ON Food.idCategory=FoodCategory.id WHERE Food.name LIKE '%'+@ten_food+'%'";
            return ketnoi.LoadDataWithParameter(sql, name, values, parameter);
        }
        public int insert_food(Food_PUBLIC food_public)
        {
            int parameter = 3;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@id_dm";
            name[1] = "@ten_food";
            name[2] = "@dongia";
            values[0] = food_public.id_dm;
            values[1] = food_public.ten_food ;
            values[2] = food_public.dongia;
            string sql = "INSERT INTO Food(idCategory,name,Gia) VALUES(@id_dm,@ten_food,@dongia)";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int update_food(Food_PUBLIC food_public)
        {
            int parameter = 4;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idfood";
            name[1] = "@id_dm";
            name[2] = "@ten_food";
            name[3] = "@dongia";
            values[0] = food_public.idfood;
            values[1] = food_public.id_dm;
            values[2] = food_public.ten_food;
            values[3] = food_public.dongia;
            string sql = "UPDATE Food SET idCategory=@id_dm,name=@ten_food,Gia=@dongia WHERE id=@idfood";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }
        public int delete_food(Food_PUBLIC food_public)
        {
            int parameter = 1;
            string[] name = new string[parameter];
            object[] values = new object[parameter];
            name[0] = "@idfood";
            values[0] = food_public.idfood;
            string sql = "DELETE FROM Food WHERE id=@idfood";
            return ketnoi.Excute_Data(sql, name, values, parameter);
        }

      
    }
}
