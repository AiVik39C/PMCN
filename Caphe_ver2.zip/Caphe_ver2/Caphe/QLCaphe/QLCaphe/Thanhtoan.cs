﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class Thanhtoan : Form
    {
       
        public static Thanhtoan thanhtoan;
        public Thanhtoan()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
            thanhtoan = this;
        }
        private int IDBAN;

        public int idban
        {
            get
            {
                return IDBAN;
            }

            set
            {
                IDBAN = value;
            }
        }

        public string tenban
        {
            get
            {
                return TENBAN;
            }

            set
            {
                TENBAN = value;
            }
        }
        private string IDNV;
        public string idnv
        {
            get
            {
                return IDNV;
            }

            set
            {
                IDNV = value;
            }
        }

        private string TENBAN;
        int idbill = 0;
        Bill_BUL bill_bul = new Bill_BUL();
        BillInfo_BUL billinfo_bul = new BillInfo_BUL();
        Ban_BUL ban_bul = new Ban_BUL();
        private void Thanhtoan_Load(object sender, EventArgs e)
        {
            txt_tongtien.ReadOnly = true;
            groupBoxhd.Text = "Hóa đơn " + tenban;
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.idban = idban;
            idbill = bill_bul.load_id_with_idban(bill_public);
            Load_BillInfo(idbill);
            tinhtongtien();           
        }
        private void Load_BillInfo(int mahoadon)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.id = mahoadon;
           // bindingSource1.DataSource = cthd_bul.load_cthd_thanhtoan(cthd_public);
            //dg_monan_ofban.DataSource = bindingSource1;
            dinhdangluoi();
        }
        private void dinhdangluoi()
        {
            datagrid_mon.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            datagrid_mon.Columns[0].HeaderText = "Mã đồ uống";
            datagrid_mon.Columns[1].HeaderText = "Tên món";
            datagrid_mon.Columns[2].HeaderText = "Số lượng";
            datagrid_mon.Columns[3].HeaderText = "Đơn giá (VNĐ)";
            datagrid_mon.Columns[3].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[4].HeaderText = "Thành tiền (VNĐ)";
            datagrid_mon.Columns[4].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[5].Visible = false;
            datagrid_mon.Columns[5].HeaderText = "Danh mục";
        }
        private void tinhtongtien()
        {          
                double tongtien = 0;
                for (int i = 0; i < datagrid_mon.Rows.Count-1; ++i)
                {
                    tongtien += Convert.ToDouble(datagrid_mon.Rows[i].Cells[4].Value.ToString());
                }
                txt_tongtien.Text = tongtien.ToString("###,###,##0");          
        }

        private void txttongtien_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btthanhtoan_MouseMove(object sender, MouseEventArgs e)
        {
            btn_thanhtoan.BackColor = Color.Chocolate;
        }

        private void btthanhtoan_MouseLeave(object sender, EventArgs e)
        {
            btn_thanhtoan.BackColor = Color.Transparent;
        }
        Bill_OLD_BUL bill_old_bul = new Bill_OLD_BUL();
        BillInfo_OLD_BUL billinfo_old_bul = new BillInfo_OLD_BUL();
     
      
           
        private void btthanhtoan_Click(object sender, EventArgs e)
        {
            Bill_OLD_PUBLIC bill_old_public = new Bill_OLD_PUBLIC();
            bill_old_public.idbill = idbill;
            bill_old_public.idban = IDBAN;
            bill_old_public.manv = IDNV;
            bill_old_public.Ngaylap = DateTime.Now;
            bill_old_public.Trangthai = "Thanh toán";
            bill_old_public.Tongtien = double.Parse(txt_tongtien.Text);
            bill_old_bul.insert_bill_old(bill_old_public);           
            BillInfo_OLD_PUBLIC billinfo_old_public = new BillInfo_OLD_PUBLIC();
            for (int i = 0; i < datagrid_mon.Rows.Count - 1; i++)
            {
                billinfo_old_public.idbill_OLD = idbill;
                billinfo_old_public.idfood = int.Parse(datagrid_mon[0, i].Value.ToString());
                billinfo_old_public.soluong = int.Parse(datagrid_mon[2, i].Value.ToString());
                billinfo_old_bul.insert_billinfo_old(billinfo_old_public);
            }
            // delete CTHD 
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            for (int j = 0; j < datagrid_mon.Rows.Count - 1; j++)
            {
                billinfo_public.idbill = idbill;
                billinfo_public.idfood= int.Parse(datagrid_mon[0, j].Value.ToString());
                billinfo_bul.delete_billinfo(billinfo_public);
            }
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.id = idbill;
            bill_bul.delete_bill(bill_public);
            // update trạng thái bàn
            Ban_PUBLIC ban_public = new Ban_PUBLIC();
            ban_public.IDBAN = idban;
            ban_public.TRANGTHAI = "Trống";
            ban_bul.update_trangthaiban(ban_public);
            this.Close();
        }
        private void dongform()
        {
            this.Close();
        }
        public void ThanhToan_FormClosing(object sender, FormClosingEventArgs e)
        {
            Ban_Danhmuc.formban_dm.Load_BillInfo(idbill);
            Ban_Danhmuc.formban_dm.taobanan();
            Ban_Danhmuc.formban_dm.datagrid_mon.DataSource = 0;
            Ban_Danhmuc.formban_dm.DSMON.Text = "Danh sách món ăn của bàn:";
        }



        internal void Thanhtoan_FormClosing(object sender, FormClosingEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
       
 }

