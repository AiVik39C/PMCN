﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QLCaphe
{
    public partial class Ban_Danhmuc : Form
    {
        public static Ban_Danhmuc formban_dm;
        public Ban_Danhmuc()
        {
            InitializeComponent();
        }

        Ban_BUL ban_bul = new Ban_BUL();
        internal void taobanan()
        {

            flowLayoutPanel1.Controls.Clear();// làm mới sơ đồ bàn
            List<Ban_PUBLIC> dsban = ban_bul.Loaddsban();
            foreach (Ban_PUBLIC dong in dsban)
            {
                Button bt = new Button();
                bt.Click += bt_click;// tạo sự kiện click cho button
                bt.Tag = dong; // dùng để xác định ID của mỗi button
                bt.Width = 90;
                bt.Height = 90;
                bt.Text = dong.TEN + "\n" + dong.TRANGTHAI;
                if (dong.TRANGTHAI == "Trống")
                {
                    bt.BackColor = Color.YellowGreen;
                }
                else if (dong.TRANGTHAI == "Có người")
                {
                    bt.BackColor = Color.Red;
                }
                flowLayoutPanel1.Controls.Add(bt);
            }
        }

        Bill_BUL bill_bul = new Bill_BUL();
        BillInfo_BUL billinfo_bul = new BillInfo_BUL();
        int idbill = 0;
        int idban = 0;
        string tenban = "";
        string IDNV;
        string trangthaiban = "";
       
        private void bt_click(object sender, EventArgs e)
        {
            idban = ((sender as Button).Tag as Ban_PUBLIC).IDBAN;
            tenban = ((sender as Button).Tag as Ban_PUBLIC).TEN;
            trangthaiban = ((sender as Button).Tag as Ban_PUBLIC).TRANGTHAI;
            DSMON.Text = "Danh sách món ăn của " + tenban;
            Bill_PUBLIC bill_public = new Bill_PUBLIC();
            bill_public.idban = idban;
            int sohoadonban = bill_bul.count_bill_ban(bill_public);
            if (sohoadonban == 0)
            {
                bill_public.idnv = IDNV;// lấy từ mã từ tài khoản nhân viên đăng nhập vào
                bill_public.dateCheckin = DateTime.Now;
                bill_public.dateCheckout = DateTime.Now;
                bill_public.trangthai = "Chưa";
                bill_bul.load_bill();
                taobanan();
            }
            else
            {

                idban = bill_bul.load_idban_with_id(bill_public);
                Load_CTHD(idban);
                numericsoluongdoan.Value = 1;
               
                
            }
              
                
            
           
        }

      
        private void btn_thanhtoan_Click(object sender, EventArgs e)
        {
            if (datagrid_mon.Rows.Count == 0)
            {
                MessageBox.Show("Chọn một bàn rồi mới thanh toán hóa đơn.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (datagrid_mon.Rows.Count == 1)
            {
                MessageBox.Show("Bàn chưa có món, không thể thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Thanhtoan tt = new Thanhtoan();
               // tt.Idban = idban;
                //tt.Tenban = tenban;
                //tt.Idnv = this.Idnv;
                tt.FormClosing += new FormClosingEventHandler(tt.Thanhtoan_FormClosing);
                tt.ShowDialog();
            }
        }
        internal void Load_BillInfo(int idban)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.idban = idban;
            bindingSource1.DataSource = billinfo_bul.load_billinfo(billinfo_public);
            datagrid_mon.DataSource = bindingSource1;
            dinhdangluoi();
        }
        private void dinhdangluoi()
        {
            datagrid_mon.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            datagrid_mon.Columns[0].HeaderText = "ID ";
            datagrid_mon.Columns[1].HeaderText = "ID Bill";
            datagrid_mon.Columns[2].HeaderText = "Tên bàn";
            datagrid_mon.Columns[3].HeaderText = "Tên NV";
            datagrid_mon.Columns[4].HeaderText = "Tên KH";
            datagrid_mon.Columns[5].HeaderText = "FoodCategory";
            datagrid_mon.Columns[6].HeaderText = "Tên món";
            datagrid_mon.Columns[7].HeaderText = "Số lượng";
            datagrid_mon.Columns[8].HeaderText = "Đơn giá (VNĐ)";
            datagrid_mon.Columns[8].DefaultCellStyle.Format = dinhdangso;
            datagrid_mon.Columns[9].HeaderText = "Thành tiền (VNĐ)";
            datagrid_mon.Columns[9].DefaultCellStyle.Format = dinhdangso;
           
        }
        internal void HideShow_ThemBan()
        {
            dg_dsban.DataSource = ban_bul.load_ban();// show lên lưới để đếm số bàn ! nếu lớn hơn 1 thì ẩn controls thêm bàn ngược lại thì hiện lên
            dg_dsban.Hide();
            if (dg_dsban.Rows.Count > 1)
            {
                lbthemban.Hide();
                Soban.Hide();
                bt_themban.Hide();
            }
            else
            {
                lbthemban.Show();
                Soban.Show();
                bt_themban.Show();
            }
        }
        private void Ban_Danhmuc_Load(object sender, EventArgs e)
        {
            
            taobanan();
            HideShow_ThemBan();
            cbdanhmuc.DropDownStyle = ComboBoxStyle.DropDownList;
            cbten.DropDownStyle = ComboBoxStyle.DropDownList;
            cbgia.DropDownStyle = ComboBoxStyle.DropDownList;
            DataTable dt = new DataTable();
            dt = dmdouong_bul.load_dmdouong();
            cbdanhmuc.DataSource = dt;
            cbdanhmuc.DisplayMember = "tendm";
            cbiddm.DataSource = dt;
            cbiddm.DisplayMember = "iddm";
            cbiddm.Hide();
            cbiddouong.Hide();
            flowLayoutPanel1.AutoScroll = true;     
        }
        int MAHOADON_XOA = 0;
        int MADOUONG_XOA = 0;
        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (datagrid_mon.Rows.Count == 0)
            {
                MessageBox.Show("Chọn một bàn rồi nhấn vào danh sánh món ăn muốn xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
                billinfo_public.id = MAHOADON_XOA;
                billinfo_public.idfood = MADOUONG_XOA;
                billinfo_bul.delete_billinfo(billinfo_public);
                Load_CTHD(idban);
            }
        }
        internal void Load_CTHD(int mahoadon)
        {
            BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
            billinfo_public.id = mahoadon;
            bindingSource1.DataSource = billinfo_bul.load_billinfo(billinfo_public);
            datagrid_mon.DataSource = bindingSource1;
            dinhdangluoi();
        }
        Food_BUL Food_BUL = new Food_BUL();
        FoodCategory_BUL dmdouong_bul = new FoodCategory_BUL();
        private void cbten_Click(object sender, EventArgs e)
        {
            try
            {
                Food_PUBLIC douong_public = new Food_PUBLIC();
                douong_public.id_dm = int.Parse(cbiddm.Text);
                DataTable dt = new DataTable();
                dt = Food_BUL.load_douongvoi_where(douong_public);
                cbten.DataSource = dt;
                cbten.DisplayMember = "TENDOUONG";
                cbgia.DataSource = dt;
                cbgia.DisplayMember = "DONGIA";
                cbiddouong.DataSource = dt;
                cbiddouong.DisplayMember = "IDDOUONG";
            }
            catch
            {
                MessageBox.Show("Danh mục trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void bt_themban_Click(object sender, EventArgs e)
        {

        }

        private void btn_chuyenban_Click(object sender, EventArgs e)
        {
            Chuyenban cb = new Chuyenban();
            cb.ShowDialog();
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (datagrid_mon.Rows.Count == 0)
            {
                MessageBox.Show("Chọn một bàn rồi thêm món.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (cbten.Text == "")
            {
                MessageBox.Show("Chưa chọn món.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                BillInfo_PUBLIC billinfo_public = new BillInfo_PUBLIC();
                Ban_PUBLIC ban_public = new Ban_PUBLIC();
                billinfo_public.idbill = idbill;
                billinfo_public.idfood = int.Parse(cbiddouong.Text);
                billinfo_public.soluong = (int)numericsoluongdoan.Value;
                billinfo_bul.insert_billinfo(billinfo_public);
                ban_public.IDBAN = idban;
                ban_public.TRANGTHAI = "Có người";
                ban_bul.update_trangthaiban(ban_public);
                if (trangthaiban == "Trống")
                {
                    taobanan();
                }
                Load_CTHD(idbill);
            }
        }

    


      
    }
}
