﻿using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCaphe
{
    public partial class CTHD_OLD : Form
    {
        public CTHD_OLD()
        {
            InitializeComponent();
        }

        BillInfo_OLD_BUL billinfo_old_bul = new BillInfo_OLD_BUL();
        private int mahoadon_old;

        public int Mahoadon_old
        {
            get
            {
                return mahoadon_old;
            }

            set
            {
                mahoadon_old = value;
            }
        }
        private void CTHD_OLD_Load(object sender, EventArgs e)
        {
            groupBox1.Text = "Chi tiết của mã hóa đơn: " + mahoadon_old.ToString();
            BillInfo_OLD_PUBLIC billinfo_old_public = new BillInfo_OLD_PUBLIC();
            billinfo_old_public.idbill_OLD= mahoadon_old;
            dg_cthd_old.DataSource = billinfo_old_bul.load_billinfo_old_printer(billinfo_old_public);
            dinhdangluoi();
            rttongtien.ReadOnly = true;
            tinhtongtien();
        }

        private void tinhtongtien()
        {
            double tongtien = 0;
            for (int i = 0; i < dg_cthd_old.Rows.Count - 1; ++i)
            {
                tongtien += Convert.ToDouble(dg_cthd_old.Rows[i].Cells[3].Value.ToString());
            }
            rttongtien.Text = tongtien.ToString("###,###,##0");
        }
        private void dinhdangluoi()
        {
            dg_cthd_old.ReadOnly = true;
            string dinhdangso = "###,###,##0";
            dg_cthd_old.Columns[0].HeaderText = "Tên món";
            dg_cthd_old.Columns[1].HeaderText = "Số lượng";
            dg_cthd_old.Columns[2].HeaderText = "Đơn giá (VNĐ)";
            dg_cthd_old.Columns[2].DefaultCellStyle.Format = dinhdangso;
            dg_cthd_old.Columns[3].HeaderText = "Thành tiền (VNĐ)";
            dg_cthd_old.Columns[3].DefaultCellStyle.Format = dinhdangso;
        }

        
    }
}
