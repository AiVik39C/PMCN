﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class NhanVien_PUBLIC
    {
        private string _manv;

        public string manv
        {
            get { return _manv; }
            set { _manv = value; }
        }
        private string _TenNV;

        public string TenNV
        {
            get { return _TenNV; }
            set { _TenNV = value; }
        }
        private DateTime _Ngaysinh;

        public DateTime Ngaysinh
        {
            get { return _Ngaysinh; }
            set { _Ngaysinh = value; }
        }
        private string _Sodienthoai;

        public string Sodienthoai
        {
            get { return _Sodienthoai; }
            set { _Sodienthoai = value; }
        }
        private string _Gioitinh;

        public string Gioitinh
        {
            get { return _Gioitinh; }
            set { _Gioitinh = value; }
        }

        private string _Username;
        public string Username
        {
            get { return _Username; }
            set { _Username = value; }
        }
        private string _Passwrd;
        public string Passwrd
        {
            get { return _Passwrd; }
            set { _Passwrd = value; }
        }
        private string _Quyen;
        public string Quyen
        {
            get { return _Quyen; }
            set { _Quyen = value; }
        }
        private string _TIMTEN;

        public string TIMTEN
        {
            get { return _TIMTEN; }
            set { _TIMTEN = value; }
        }
    }
}
