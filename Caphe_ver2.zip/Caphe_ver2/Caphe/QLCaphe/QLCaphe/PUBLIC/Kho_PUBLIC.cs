﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class Kho_PUBLIC
    {
        private string _mamh;

        public string mamh
        {
            get { return _mamh; }
            set { _mamh = value; }
        }
        private string _Tenhang;

        public string Tenhang
        {
            get { return _Tenhang; }
            set { _Tenhang = value; }
        }
        private Decimal _Gia;

        public Decimal Gia
        {
            get { return _Gia; }
            set { _Gia = value; }
        }
        private string _DVT;

        public string DVT
        {
            get { return _DVT; }
            set { _DVT = value; }
        }
        private DateTime _Ngaynhap;

        public DateTime Ngaynhap
        {
            get { return _Ngaynhap; }
            set { _Ngaynhap = value; }
        }
        private string _Timten;

        public string Timten
        {
            get { return _Timten; }
            set { _Timten = value; }
        }
    }
}
