﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class Bill_PUBLIC
    {
        private int _id;

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        private int _idban;

        public int idban
        {
            get { return _idban; }
            set { _idban = value; }
        }
        private string _idnv;


        private DateTime _dateCheckin;

        public DateTime dateCheckin
        {
            get { return _dateCheckin; }
            set { _dateCheckin = value; }
        }

        private DateTime _dateCheckout;

        public DateTime dateCheckout
        {
            get { return _dateCheckout; }
            set { _dateCheckout = value; }
        }
        private string _trangthai;


        public string idnv
        {
            get
            {
                return _idnv;
            }

            set
            {
                _idnv = value;
            }
        }

        public string trangthai
        {
            get
            {
                return _trangthai;
            }

            set
            {
                _trangthai = value;
            }
        }
    }
}
