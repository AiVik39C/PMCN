﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCaphe.PUBLIC
{
    public class Ban_PUBLIC
    {
        public Ban_PUBLIC(int IDBAN, string TEN, string TRANGTHAI)
        {
            this.IDBAN = IDBAN;
            this._TEN = TEN;
            this.TRANGTHAI = TRANGTHAI;
        }
        public Ban_PUBLIC(DataRow rows)
        {
            this.IDBAN = (int)rows["IDBAN"];
            this.TEN = rows["TEN"].ToString();
            this.TRANGTHAI = rows["TRANGTHAI"].ToString();
        }
        public Ban_PUBLIC()
        {
        }
        private int _IDBAN;

        public int IDBAN
        {
            get { return _IDBAN; }
            set { _IDBAN = value; }
        }
        private string _TEN;

        public string TEN
        {
            get { return _TEN; }
            set { _TEN = value; }
        }

        public string TRANGTHAI
        {
            get
            {
                return _TRANGTHAI;
            }

            set
            {
                _TRANGTHAI = value;
            }
        }

        public int ODER
        {
            get
            {
                return _ODER;
            }

            set
            {
                _ODER = value;
            }
        }

        private string _TRANGTHAI;
        private int _ODER;

        public string TENBAN { get; set; }

        public int ID { get; set; }
    }
    
}
