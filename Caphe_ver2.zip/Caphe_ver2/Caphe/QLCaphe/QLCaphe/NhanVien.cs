﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLCaphe.BUL;
using QLCaphe.PUBLIC;
using System.Data.SqlClient;
namespace QLCaphe
{
    public partial class NhanVien : Form
    {
        public NhanVien()
        {
            
            InitializeComponent();
            
        }
         private void xulybuttion(bool b)
        {
            btn_Them.Enabled = datagrid_nhanvien.Enabled = btn_tim.Enabled = btn_lammoi.Enabled = txt_tim.Enabled = btn_Sua.Enabled = btn_Xoa.Enabled = btn_Toi.Enabled = btn_Lui.Enabled = btn_Thoat.Enabled = b;
            btn_Luu.Enabled = btn_Huy.Enabled = !b;
        }
        private bool nutThem = false, nutSua = false;
        private void NhanVien_Load(object sender, EventArgs e)
        {
            xulybuttion(true);
            LoadDataGrid();
            EditDataGrid();          
          
        }
        

      NhanVien_BUL nhanvien_bul = new NhanVien_BUL();
        int manv;
      
        private void LoadDataGrid()
        {
            bindingSource1.DataSource = nhanvien_bul.load_nhanvien();
            datagrid_nhanvien.DataSource = bindingSource1;
        }
        private void EditDataGrid()
        {
            datagrid_nhanvien.ReadOnly = true;
            datagrid_nhanvien.Columns[0].HeaderText = "Mã nhân viên";
            datagrid_nhanvien.Columns[1].HeaderText = "Tên nhân viên";
            datagrid_nhanvien.Columns[2].HeaderText = "Ngày sinh";
            datagrid_nhanvien.Columns[3].HeaderText = "Số điện thoại";
            datagrid_nhanvien.Columns[4].HeaderText = "Giới tính";
            datagrid_nhanvien.Columns[5].HeaderText = "Tên tài khoản";
            datagrid_nhanvien.Columns[6].HeaderText = "Mật khẩu";
            datagrid_nhanvien.Columns[7].HeaderText = "Quyền";
           
        }

        private void datagrid_nhanvien_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
                int dong = e.RowIndex;
                txt_manv.Text = datagrid_nhanvien.Rows[dong].Cells[0].Value.ToString();
                txt_tennv.Text = datagrid_nhanvien.Rows[dong].Cells[1].Value.ToString();
                date_ngaysinh.Text = datagrid_nhanvien.Rows[dong].Cells[2].Value.ToString();
                txt_sdt.Text = datagrid_nhanvien.Rows[dong].Cells[3].Value.ToString();
                cb_gioitinh.Text = datagrid_nhanvien.Rows[dong].Cells[4].Value.ToString();
                txt_tentk.Text = datagrid_nhanvien.Rows[dong].Cells[5].Value.ToString();
                txt_matkhau.Text = datagrid_nhanvien.Rows[dong].Cells[6].Value.ToString();
                cb_quyen.Text = datagrid_nhanvien.Rows[dong].Cells[7].Value.ToString();

          
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            nutThem = true;
            txt_manv.Hide();
            xulybuttion(false);
            txt_tennv.Focus();
            Clear();
        }
        private void Clear()
        {
            txt_tennv.Clear();
            date_ngaysinh.ResetText();
            txt_sdt.Clear();
            cb_gioitinh.SelectedIndex = -1;
            txt_tentk.Clear();
            txt_matkhau.Clear();
            cb_quyen.SelectedIndex = -1;
           
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            nutSua = true;
          
            txt_tentk.ReadOnly = false;
            xulybuttion(false);
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Muốn xóa một nhân viên?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
               
               
                DeleteNhanVien();
                LoadDataGrid();
            }
        }
       
        private void DeleteNhanVien()
        {
            NhanVien_PUBLIC nhanvien_public = new NhanVien_PUBLIC();
            nhanvien_public.manv = txt_manv.Text;
            nhanvien_bul.delete_nhanvien(nhanvien_public);
        }
        private void InsertNhanVien()
        {
            NhanVien_PUBLIC nhanvien_public = new NhanVien_PUBLIC();
            manv = nhanvien_bul.count_nhanvien();
            nhanvien_public.manv = "NV" + manv.ToString();
            nhanvien_public.TenNV = txt_tennv.Text;
            nhanvien_public.Ngaysinh = DateTime.Parse(date_ngaysinh.Text);
            nhanvien_public.Sodienthoai = txt_sdt.Text;
            nhanvien_public.Gioitinh = cb_gioitinh.Text;
            nhanvien_public.Username = txt_tentk.Text;
            nhanvien_public.Passwrd = txt_matkhau.Text;
            nhanvien_public.Quyen = cb_quyen.Text;
            nhanvien_bul.insert_nhanvien(nhanvien_public);
        }
       
        private void UpdateNhanVien()
        {
            NhanVien_PUBLIC nhanvien_public = new NhanVien_PUBLIC();
            nhanvien_public.manv = txt_manv.Text;
            nhanvien_public.TenNV = txt_tennv.Text;
            nhanvien_public.Ngaysinh  = DateTime.Parse(date_ngaysinh.Text);
            nhanvien_public.Sodienthoai = txt_sdt.Text;
            nhanvien_public.Gioitinh = cb_gioitinh.Text;
            nhanvien_public.Username = txt_tentk.Text;
            nhanvien_public.Passwrd = txt_matkhau.Text;
            nhanvien_public.Quyen = cb_quyen.Text;
            nhanvien_bul.update_nhanvien(nhanvien_public);
        }
       
        private void DeleteNhanVien_Loi()
        {
            NhanVien_PUBLIC nhanvien_public = new NhanVien_PUBLIC();
            nhanvien_public.manv = "NV" + manv.ToString();
            nhanvien_bul.delete_nhanvien(nhanvien_public);
        }
        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                if (txt_tennv.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên nhân viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (date_ngaysinh.Value.Year == DateTime.Today.Year)
                {
                    MessageBox.Show("Chưa chọn ngày sinh.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                //else if (txtsdt.TextLength == 0)
                //{
                //    MessageBox.Show("Chưa nhập số điện thoại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}
                else if (cb_gioitinh.Text == "")
                {
                    MessageBox.Show("Chưa chọn giới tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tentk.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên tài khoản.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền mật khẩu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength < 6)
                {
                    MessageBox.Show("Mật khẩu quá ngắn, phải lớn hơn 6 ký tự.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (cb_quyen.Text == "")
                {
                    MessageBox.Show("Chưa chọn quyền.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                
                else if (txt_tentk.TextLength <= 3)
                {
                    MessageBox.Show("Tên tài khoản quá ngắn, phải dài hơn 3 ký tự.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tennv.TextLength >= 100)
                {
                    MessageBox.Show("Tên nhân viên quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_sdt.TextLength >= 13)
                {
                    MessageBox.Show("Số điện thoại quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tentk.TextLength >= 50)
                {
                    MessageBox.Show("Tên tài quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength > 20)
                {
                    MessageBox.Show("Mật khẩu quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    try
                    {
                        nutThem = false;
                        InsertNhanVien();
                        LoadDataGrid();
                        xulybuttion(true);
                    }
                    catch 
                    {
                    }
                }
            }
            else if (nutSua == true)
            {
                if (txt_tennv.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên nhân viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (date_ngaysinh.Value.Year == DateTime.Today.Year)
                {
                    MessageBox.Show("Chưa chọn ngày sinh.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                //else if (txtsdt.TextLength == 0)
                //{
                //    MessageBox.Show("Chưa nhập số điện thoại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //}
                else if (cb_gioitinh.Text == "")
                {
                    MessageBox.Show("Chưa chọn giới tính.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tentk.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền tên tài khoản.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength == 0)
                {
                    MessageBox.Show("Chưa điền mật khẩu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength < 6)
                {
                    MessageBox.Show("Mật khẩu quá ngắn, phải lớn hơn 6 ký tự.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (cb_quyen.Text == "")
                {
                    MessageBox.Show("Chưa chọn quyền.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
               
                else if (txt_tennv.TextLength >= 100)
                {
                    MessageBox.Show("Tên nhân viên quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_sdt.TextLength >= 13)
                {
                    MessageBox.Show("Số điện thoại quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_tentk.TextLength >= 50)
                {
                    MessageBox.Show("Tên tài quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txt_matkhau.TextLength > 20)
                {
                    MessageBox.Show("Mật khẩu quá dài.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {

                    UpdateNhanVien();
                    xulybuttion(true);
                    nutSua = false;
                    LoadDataGrid();
                }
            }
        }

        private void btn_Huy_Click(object sender, EventArgs e)
        {
            if (nutThem == true)
            {
                //
                LoadDataGrid();
                xulybuttion(true);
                nutThem = false;
            }
            else if (nutSua == true)
            {
                //
                xulybuttion(true);
                nutSua = false;
            }
        }

        private void btn_Lui_Click(object sender, EventArgs e)
        {
            try
            {
                int lui = datagrid_nhanvien.CurrentRow.Index - 1;
                if (lui != datagrid_nhanvien.Rows.Count + 1)
                {
                    datagrid_nhanvien.CurrentCell = datagrid_nhanvien.Rows[lui].Cells[datagrid_nhanvien.CurrentCell.ColumnIndex];
                    datagrid_nhanvien.Rows[lui].Selected = true;
                }
            }
            catch
            { }           
        }

        private void btn_Toi_Click(object sender, EventArgs e)
        {
            try
            {
                int toi = datagrid_nhanvien.CurrentRow.Index + 1;
                if (toi != datagrid_nhanvien.Rows.Count - 1)
                {
                    datagrid_nhanvien.CurrentCell = datagrid_nhanvien.Rows[toi].Cells[datagrid_nhanvien.CurrentCell.ColumnIndex];
                    datagrid_nhanvien.Rows[toi].Selected = true;
                }
            }
            catch
            { }       
        }

        private void btn_tim_Click(object sender, EventArgs e)
        {
            if (txt_tim.TextLength == 0)
            {
                MessageBox.Show("Chưa nhập tên nhân viên cần tìm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                NhanVien_PUBLIC nhanvien_public = new NhanVien_PUBLIC();
                nhanvien_public.TIMTEN = txt_tim.Text;
                datagrid_nhanvien.DataSource = nhanvien_bul.Tim_nv(nhanvien_public);
                datagrid_nhanvien.Rows[0].Selected = true;
            }
        }

        private void btn_lammoi_Click(object sender, EventArgs e)
        {

            datagrid_nhanvien.DataSource = nhanvien_bul.load_nhanvien();
            txt_tim.Clear();
        }

        private void ChiDuocNhapSo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // chỉ cho phép dấu thập phân
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void sdt_keyPress(object sender, KeyPressEventArgs e)
        {
            ChiDuocNhapSo(sender, e);
        }
        int index;
        private void datagrid_nhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             
            index = datagrid_nhanvien.CurrentRow.Index;
            txt_manv.Text = datagrid_nhanvien.Rows[index].Cells[0].Value.ToString();
            txt_tennv.Text = datagrid_nhanvien.Rows[index].Cells[1].Value.ToString();
            date_ngaysinh.Text = datagrid_nhanvien.Rows[index].Cells[2].Value.ToString();
            txt_sdt.Text = datagrid_nhanvien.Rows[index].Cells[3].Value.ToString();
            cb_gioitinh.Text = datagrid_nhanvien.Rows[index].Cells[4].Value.ToString();
            txt_tentk.Text = datagrid_nhanvien.Rows[index].Cells[5].Value.ToString();
            txt_matkhau.Text = datagrid_nhanvien.Rows[index].Cells[6].Value.ToString();
            cb_quyen.Text = datagrid_nhanvien.Rows[index].Cells[7].Value.ToString();
        
        }

        private void datagrid_nhanvien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = datagrid_nhanvien.CurrentRow.Index;
            txt_manv.Text = datagrid_nhanvien.Rows[index].Cells[0].Value.ToString();
            txt_tennv.Text = datagrid_nhanvien.Rows[index].Cells[1].Value.ToString();
            date_ngaysinh.Text = datagrid_nhanvien.Rows[index].Cells[2].Value.ToString();
            txt_sdt.Text = datagrid_nhanvien.Rows[index].Cells[3].Value.ToString();
            cb_gioitinh.Text = datagrid_nhanvien.Rows[index].Cells[4].Value.ToString();
            txt_tentk.Text = datagrid_nhanvien.Rows[index].Cells[5].Value.ToString();
            txt_matkhau.Text = datagrid_nhanvien.Rows[index].Cells[6].Value.ToString();
            cb_quyen.Text = datagrid_nhanvien.Rows[index].Cells[7].Value.ToString();
        }


    }
}
